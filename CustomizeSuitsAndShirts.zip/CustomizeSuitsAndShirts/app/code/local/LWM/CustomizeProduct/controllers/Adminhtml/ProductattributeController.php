<?php

class LWM_CustomizeProduct_Adminhtml_ProductattributeController extends Mage_Adminhtml_Controller_Action
{
		protected function _initAction()
		{
				$this->loadLayout()->_setActiveMenu("customizeproduct/productattribute")->_addBreadcrumb(Mage::helper("adminhtml")->__("Productattribute  Manager"),Mage::helper("adminhtml")->__("Productattribute Manager"));
				return $this;
		}
		public function indexAction() 
		{
			    $this->_title($this->__("CustomizeProduct"));
			    $this->_title($this->__("Manager Productattribute"));

				$this->_initAction();
				$this->renderLayout();
		}
		public function editAction()
		{			    
			    $this->_title($this->__("CustomizeProduct"));
				$this->_title($this->__("Productattribute"));
			    $this->_title($this->__("Edit Item"));
				
				$id = $this->getRequest()->getParam("id");
				$model = Mage::getModel("customizeproduct/productattribute")->load($id);
				if ($model->getId()) {
					Mage::register("productattribute_data", $model);
					$this->loadLayout();
					$this->_setActiveMenu("customizeproduct/productattribute");
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Productattribute Manager"), Mage::helper("adminhtml")->__("Productattribute Manager"));
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Productattribute Description"), Mage::helper("adminhtml")->__("Productattribute Description"));
					$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);
					$this->_addContent($this->getLayout()->createBlock("customizeproduct/adminhtml_productattribute_edit"))->_addLeft($this->getLayout()->createBlock("customizeproduct/adminhtml_productattribute_edit_tabs"));
					$this->renderLayout();
				} 
				else {
					Mage::getSingleton("adminhtml/session")->addError(Mage::helper("customizeproduct")->__("Item does not exist."));
					$this->_redirect("*/*/");
				}
		}

		public function newAction()
		{

		$this->_title($this->__("CustomizeProduct"));
		$this->_title($this->__("Productattribute"));
		$this->_title($this->__("New Item"));

        $id   = $this->getRequest()->getParam("id");
		$model  = Mage::getModel("customizeproduct/productattribute")->load($id);

		$data = Mage::getSingleton("adminhtml/session")->getFormData(true);
		if (!empty($data)) {
			$model->setData($data);
		}

		Mage::register("productattribute_data", $model);

		$this->loadLayout();
		$this->_setActiveMenu("customizeproduct/productattribute");

		$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Productattribute Manager"), Mage::helper("adminhtml")->__("Productattribute Manager"));
		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Productattribute Description"), Mage::helper("adminhtml")->__("Productattribute Description"));


		$this->_addContent($this->getLayout()->createBlock("customizeproduct/adminhtml_productattribute_edit"))->_addLeft($this->getLayout()->createBlock("customizeproduct/adminhtml_productattribute_edit_tabs"));

		$this->renderLayout();

		}
		public function saveAction()
		{

		 $post_data=$this->getRequest()->getPost();	
		 /*echo "<pre>";
		 print_r( $options=$post_data['productattribute']['options']);
		 exit;*/
		 if ($post_data) {

					try {
					/*
					* Set the options to customize product attribute 
					*/	
					if(isset($post_data['productattribute'])){
					   $options=$post_data['productattribute']['options'];	
						foreach($options as $option_data){
							$option = Mage::getSingleton('customizeproduct/productattribute_option')
								->addOption($option_data);	
						} 
					$post_data['has_options']=1;	
					}
					if((bool)$post_data['ptype_attribute_front_image']['delete']==1) {
                       $post_data['ptype_attribute_front_image']='';
					 }else{
						 unset($post_data['ptype_attribute_front_image']);
						 if (isset($_FILES)){
								if ($_FILES['ptype_attribute_front_image']['name']) {

									if($this->getRequest()->getParam("id")){
										$model = Mage::getModel("customizeproduct/productattribute")->load($this->getRequest()->getParam("id"));
										if($model->getData('ptype_attribute_front_image')){
												$io = new Varien_Io_File();
												$io->rm(Mage::getBaseDir('media').DS.implode(DS,explode('/',$model->getData('ptype_attribute_front_image'))));	
										}
									}
												$path = Mage::getBaseDir('media') . DS . 'customizeproduct' . DS .'productattribute'.DS."front".DS;
												$uploader = new Varien_File_Uploader('ptype_attribute_front_image');
												$uploader->setAllowedExtensions(array('jpg','png','gif'));
												$uploader->setAllowRenameFiles(false);
												$uploader->setFilesDispersion(false);
												$destFile = $path.$_FILES['ptype_attribute_front_image']['name'];
												$filename = $uploader->getNewFileName($destFile);
												$uploader->save($path, $filename);
												$post_data['ptype_attribute_front_image']='customizeproduct/productattribute/front/'.$filename;
								}
							}
					 }
				     $model = Mage::getModel("customizeproduct/productattribute")
						->addData($post_data)
						->setData('ptype_attribute_group', $post_data['ptype_attribute_group'])
						->setId($this->getRequest()->getParam("id"))
						
						->save();
					
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Productattribute was successfully saved"));
						Mage::getSingleton("adminhtml/session")->setProductattributeData(false);

						if ($this->getRequest()->getParam("back")) {
							$this->_redirect("*/*/edit", array("id" => $model->getId()));
							return;
						}
						$this->_redirect("*/*/");
						return;
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						Mage::getSingleton("adminhtml/session")->setProductattributeData($this->getRequest()->getPost());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					return;
					}

				}
				$this->_redirect("*/*/");
		}



		public function deleteAction()
		{
				if( $this->getRequest()->getParam("id") > 0 ) {
					try {
						$model = Mage::getModel("customizeproduct/productattribute");
						$model->setId($this->getRequest()->getParam("id"))->delete();
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item was successfully deleted"));
						$this->_redirect("*/*/");
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					}
				}
				$this->_redirect("*/*/");
		}

		
		public function massRemoveAction()
		{
			try {
				$ids = $this->getRequest()->getPost('ptype_attribute_ids', array());
				foreach ($ids as $id) {
                      $model = Mage::getModel("customizeproduct/productattribute");
					  $model->setId($id)->delete();
				}
				Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item(s) was successfully removed"));
			}
			catch (Exception $e) {
				Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
			}
			$this->_redirect('*/*/');
		}
			
		/**
		 * Export order grid to CSV format
		 */
		public function exportCsvAction()
		{
			$fileName   = 'productattribute.csv';
			$grid       = $this->getLayout()->createBlock('customizeproduct/adminhtml_productattribute_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
		} 
		/**
		 *  Export order grid to Excel XML format
		 */
		public function exportExcelAction()
		{
			$fileName   = 'productattribute.xml';
			$grid       = $this->getLayout()->createBlock('customizeproduct/adminhtml_productattribute_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
		}
}
