<?php

class LWM_CustomizeProduct_Adminhtml_ProducttypeController extends Mage_Adminhtml_Controller_Action
{
		protected function _initAction()
		{
				$this->loadLayout()->_setActiveMenu("customizeproduct/producttype")->_addBreadcrumb(Mage::helper("adminhtml")->__("Producttype  Manager"),Mage::helper("adminhtml")->__("Product Type Manager"));
				return $this;
		}
		public function indexAction() 
		{
			    $this->_title($this->__("CustomizeProduct"));
			    $this->_title($this->__("Manager Producttype"));

				$this->_initAction();
				$this->renderLayout();
		}
		public function editAction()
		{			    
			    $this->_title($this->__("CustomizeProduct"));
				$this->_title($this->__("Producttype"));
			    $this->_title($this->__("Edit Item"));
				
				$id = $this->getRequest()->getParam("id");
				$model = Mage::getModel("customizeproduct/producttype")->load($id);
				if ($model->getId()) {
					Mage::register("producttype_data", $model);
					$this->loadLayout();
					$this->_setActiveMenu("customizeproduct/producttype");
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Producttype Manager"), Mage::helper("adminhtml")->__("Producttype Manager"));
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Producttype Description"), Mage::helper("adminhtml")->__("Producttype Description"));
					$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);
					$this->_addContent($this->getLayout()->createBlock("customizeproduct/adminhtml_producttype_edit"))->_addLeft($this->getLayout()->createBlock("customizeproduct/adminhtml_producttype_edit_tabs"));
					$this->renderLayout();
				} 
				else {
					Mage::getSingleton("adminhtml/session")->addError(Mage::helper("customizeproduct")->__("Item does not exist."));
					$this->_redirect("*/*/");
				}
		}

		public function newAction()
		{
		$collection  = Mage::getModel("customizeproduct/producttype")->getCollection(); 
		$count=$collection->getSize();
		/* if($count>2){ */
		$this->_title($this->__("CustomizeProduct"));
		$this->_title($this->__("Producttype"));
		$this->_title($this->__("New Item"));

        $id   = $this->getRequest()->getParam("id");
		$model  = Mage::getModel("customizeproduct/producttype")->load($id);

		$data = Mage::getSingleton("adminhtml/session")->getFormData(true);
		if (!empty($data)) {
			$model->setData($data);
		}

		Mage::register("producttype_data", $model);

		$this->loadLayout();
		$this->_setActiveMenu("customizeproduct/producttype");

		$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Producttype Manager"), Mage::helper("adminhtml")->__("Producttype Manager"));
		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Producttype Description"), Mage::helper("adminhtml")->__("Producttype Description"));


		$this->_addContent($this->getLayout()->createBlock("customizeproduct/adminhtml_producttype_edit"))->_addLeft($this->getLayout()->createBlock("customizeproduct/adminhtml_producttype_edit_tabs"));

		$this->renderLayout();
      /*   }else{
		 Mage::getSingleton("adminhtml/session")->addError(Mage::helper("customizeproduct")->__("Not possible to add more than two product type.")); */	
		 //$this->_redirect("*/*/");	
		//}
		}
		public function saveAction()
		{
			$post_data=$this->getRequest()->getPost();


				if ($post_data) {

					try {

						
				 //save image
		try{

if((bool)$post_data['ptype_base_front_image']['delete']==1) {

	        $post_data['ptype_base_front_image']='';

}
else {

	unset($post_data['ptype_base_front_image']);

	if (isset($_FILES)){

		if ($_FILES['ptype_base_front_image']['name']) {

			if($this->getRequest()->getParam("id")){
				$model = Mage::getModel("customizeproduct/producttype")->load($this->getRequest()->getParam("id"));
				if($model->getData('ptype_base_front_image')){
						$io = new Varien_Io_File();
						$io->rm(Mage::getBaseDir('media').DS.implode(DS,explode('/',$model->getData('ptype_base_front_image'))));	
				}
			}
						$path = Mage::getBaseDir('media') . DS . 'customizeproduct' . DS .'producttype'.DS;
						$uploader = new Varien_File_Uploader('ptype_base_front_image');
						$uploader->setAllowedExtensions(array('jpg','png','gif'));
						$uploader->setAllowRenameFiles(false);
						$uploader->setFilesDispersion(false);
						$destFile = $path.$_FILES['ptype_base_front_image']['name'];
						$filename = $uploader->getNewFileName($destFile);
						$uploader->save($path, $filename);

						$post_data['ptype_base_front_image']='customizeproduct/producttype/'.$filename;
		}
    }
}

        } catch (Exception $e) {
				Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
				$this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
				return;
        }
//save image

				 //save image
		try{

if((bool)$post_data['ptype_base_back_image']['delete']==1) {

	        $post_data['ptype_base_back_image']='';

}
else {

	unset($post_data['ptype_base_back_image']);

	if (isset($_FILES)){

		if ($_FILES['ptype_base_back_image']['name']) {

			if($this->getRequest()->getParam("id")){
				$model = Mage::getModel("customizeproduct/producttype")->load($this->getRequest()->getParam("id"));
				if($model->getData('ptype_base_back_image')){
						$io = new Varien_Io_File();
						$io->rm(Mage::getBaseDir('media').DS.implode(DS,explode('/',$model->getData('ptype_base_back_image'))));	
				}
			}
						$path = Mage::getBaseDir('media') . DS . 'customizeproduct' . DS .'producttype'.DS;
						$uploader = new Varien_File_Uploader('ptype_base_back_image');
						$uploader->setAllowedExtensions(array('jpg','png','gif'));
						$uploader->setAllowRenameFiles(false);
						$uploader->setFilesDispersion(false);
						$destFile = $path.$_FILES['ptype_base_back_image']['name'];
						$filename = $uploader->getNewFileName($destFile);
						$uploader->save($path, $filename);

						$post_data['ptype_base_back_image']='customizeproduct/producttype/'.$filename;
		}
    }
}

        } catch (Exception $e) {
				Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
				$this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
				return;
        }
//save image


						$model = Mage::getModel("customizeproduct/producttype")
						->addData($post_data)
						->setId($this->getRequest()->getParam("id"))
						->save();

						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Producttype was successfully saved"));
						Mage::getSingleton("adminhtml/session")->setProducttypeData(false);

						if ($this->getRequest()->getParam("back")) {
							$this->_redirect("*/*/edit", array("id" => $model->getId()));
							return;
						}
						$this->_redirect("*/*/");
						return;
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						Mage::getSingleton("adminhtml/session")->setProducttypeData($this->getRequest()->getPost());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					return;
					}

				}
				$this->_redirect("*/*/");
		}



		public function deleteAction()
		{
				if( $this->getRequest()->getParam("id") > 0 ) {
					try {
						$model = Mage::getModel("customizeproduct/producttype");
						$model->setId($this->getRequest()->getParam("id"))->delete();
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item was successfully deleted"));
						$this->_redirect("*/*/");
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					}
				}
				$this->_redirect("*/*/");
		}

		
		public function massRemoveAction()
		{
			try {
				$ids = $this->getRequest()->getPost('ptype_ids', array());
				foreach ($ids as $id) {
                      $model = Mage::getModel("customizeproduct/producttype");
					  $model->setId($id)->delete();
				}
				Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item(s) was successfully removed"));
			}
			catch (Exception $e) {
				Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
			}
			$this->_redirect('*/*/');
		}
			
		/**
		 * Export order grid to CSV format
		 */
		public function exportCsvAction()
		{
			$fileName   = 'producttype.csv';
			$grid       = $this->getLayout()->createBlock('customizeproduct/adminhtml_producttype_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
		} 
		/**
		 *  Export order grid to Excel XML format
		 */
		public function exportExcelAction()
		{
			$fileName   = 'producttype.xml';
			$grid       = $this->getLayout()->createBlock('customizeproduct/adminhtml_producttype_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
		}
}
