<?php 

class LWM_CustomizeProduct_CustomerController extends Mage_Core_Controller_Front_Action
{    
    /**
     * Checking if user is logged in or not
     * If not logged in then redirect to customer login
     */
    public function preDispatch()
    {
           parent::preDispatch();
 
           if (!Mage::getSingleton('customer/session')->authenticate($this)) {
            $this->setFlag('', 'no-dispatch', true);
            
        // adding message in customer login page
        Mage::getSingleton('core/session')
                ->addError(Mage::helper('customizeproduct')->__('Please sign in or create a new account'));
        }
    }            
                
    /**
     * View Size Options 
     */
    public function viewAction()
    {                    
    $this->loadLayout();        
      $this->getLayout()->getBlock('head')->setTitle($this->__('Manage Your Size Options'));        
    $this->renderLayout();
    }                
	/**
     * Create customer account action
     */
    public function createPostAction()
    {
        $errUrl = Mage::getUrl('*/*/view', array('_secure' => true));
       	
		
        if (!$this->_validateFormKey()) {
            $this->_redirectError($errUrl);
            return;
        }

        /** @var $session Mage_Customer_Model_Session */
        $session =Mage::getSingleton('customer/session');
        if (!$session->isLoggedIn()) {
            $this->_redirect('*/*/');
            return;
        }

        if (!$this->getRequest()->isPost()) {
            $this->_redirectError($errUrl);
            return;
        }
     
        $customer = $session->getCustomer();
        $post_data=$this->getRequest()->getPost();
        try {
            if(isset($post_data['jacket'])){
				 $model = Mage::getModel("customizeproduct/measurement")
						->addData($post_data['jacket']);			
					if($post_data['id']!=''){
						$model->setId($post_data['id']);
					}	
					$model->save();
					Mage::getSingleton('core/session')->addSuccess($this->__('Jacket size saved successfully.'));
			}elseif(isset($post_data['shirt'])){
				$model = Mage::getModel("customizeproduct/measurement")
						->addData($post_data['shirt']);
				if($post_data['id']!=''){
					$model->setId($post_data['id']);
				}		
				$model->save();
				Mage::getSingleton('core/session')->addSuccess($this->__('Shirt size saved successfully.'));			
			}elseif(isset($post_data['pant'])){
				$model = Mage::getModel("customizeproduct/pantsize")
						->addData($post_data['pant']);
				if($post_data['id']!=''){
					$model->setId($post_data['id']);
				}
				$model->save();	
				Mage::getSingleton('core/session')
                ->addSuccess($this->__('Pant size saved successfully.'));	
			}	
        } catch (Mage_Core_Exception $e) {
			
            Mage::getSingleton('core/session')
                ->addError($message);
        } catch (Exception $e) {
            Mage::getSingleton('core/session')
                ->addException($e, $this->__('Cannot save the size.'));
        }

        $this->_redirectError($errUrl);
    }
}    