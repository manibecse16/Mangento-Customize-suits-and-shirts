<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Edit Product type for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */	
class LWM_CustomizeProduct_Block_Adminhtml_Producttype_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
		public function __construct()
		{

				parent::__construct();
				$this->_objectId = "ptype_id";
				$this->_blockGroup = "customizeproduct";
				$this->_controller = "adminhtml_producttype";
				$this->_updateButton("save", "label", Mage::helper("customizeproduct")->__("Save Item"));
				$this->_updateButton("delete", "label", Mage::helper("customizeproduct")->__("Delete Item"));

				$this->_addButton("saveandcontinue", array(
					"label"     => Mage::helper("customizeproduct")->__("Save And Continue Edit"),
					"onclick"   => "saveAndContinueEdit()",
					"class"     => "save",
				), -100);



				$this->_formScripts[] = "

							function saveAndContinueEdit(){
								editForm.submit($('edit_form').action+'back/edit/');
							}
						";
		}

		public function getHeaderText()
		{
				if( Mage::registry("producttype_data") && Mage::registry("producttype_data")->getId() ){

				    return Mage::helper("customizeproduct")->__("Edit Item '%s'", $this->htmlEscape(Mage::registry("producttype_data")->getPtypeName()));

				} 
				else{

				     return Mage::helper("customizeproduct")->__("Add Item");

				}
		}
}