<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Product attribute Grid for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */	
class LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

		public function __construct()
		{
				parent::__construct();
				$this->setId("productattributeGrid");
				$this->setDefaultSort("ptype_attribute_id");
				$this->setDefaultDir("DESC");
				$this->setSaveParametersInSession(true);
		}

		protected function _prepareCollection()
		{
				$collection = Mage::getModel("customizeproduct/productattribute")->getCollection();
				$this->setCollection($collection);
				return parent::_prepareCollection();
		}
		protected function _prepareColumns()
		{
				$this->addColumn("ptype_attribute_id", array(
				"header" => Mage::helper("customizeproduct")->__("ID"),
				"align" =>"right",
				"width" => "50px",
			    "type" => "number",
				"index" => "ptype_attribute_id",
				));
                
				$this->addColumn("ptype_attribute_name", array(
				"header" => Mage::helper("customizeproduct")->__("Name"),
				"index" => "ptype_attribute_name",
				));
				$this->addColumn('ptype_id', array(
						'header' => Mage::helper('customizeproduct')->__('Product Type'),
						'index' => 'ptype_id',
						'type' => 'options',
						'options'=>LWM_CustomizeProduct_Block_Adminhtml_Producttype_Grid::getValueProductOptionValue(),				
						));
						
						$this->addColumn('ptype_attribute_pattern', array(
						'header' => Mage::helper('customizeproduct')->__('Attribute Pattern'),
						'index' => 'ptype_attribute_pattern',
						'type' => 'options',
						'options'=>LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid::getOptionArray5(),				
						));
						
			$this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV')); 
			$this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

				return parent::_prepareColumns();
		}

		public function getRowUrl($row)
		{
			   return $this->getUrl("*/*/edit", array("id" => $row->getId()));
		}


		
		protected function _prepareMassaction()
		{
			$this->setMassactionIdField('ptype_attribute_id');
			$this->getMassactionBlock()->setFormFieldName('ptype_attribute_ids');
			$this->getMassactionBlock()->setUseSelectAll(true);
			$this->getMassactionBlock()->addItem('remove_productattribute', array(
					 'label'=> Mage::helper('customizeproduct')->__('Remove Productattribute'),
					 'url'  => $this->getUrl('*/adminhtml_productattribute/massRemove'),
					 'confirm' => Mage::helper('customizeproduct')->__('Are you sure?')
				));
			return $this;
		}
			
		static public function getOptionArray4()
		{
            $data_array=array(); 
			$data_array[0]='Front View';
			$data_array[1]='Back View';
            return($data_array);
		}
		static public function getValueArray4()
		{
            $data_array=array();
			foreach(LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid::getOptionArray4() as $k=>$v){
               $data_array[]=array('value'=>$k,'label'=>$v);		
			}
            return($data_array);

		}
		
		static public function getOptionArray5()
		{
            $data_array=array(); 
			$data_array[0]='Normal Display';
			$data_array[1]='Pocket Style Display';
            return($data_array);
		}
		static public function getValueArray5()
		{
            $data_array=array();
			foreach(LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid::getOptionArray5() as $k=>$v){
               $data_array[]=array('value'=>$k,'label'=>$v);		
			}
            return($data_array);

		}
		static public function getOptionAttributeGroup()
		{
            $data_array=array(); 
			$data_array['']='';
			$data_array['suits']='Suits';
			$data_array['pants']='Pants';
			$data_array['shirts']='Shirts';
            return($data_array);
		}
		static public function getValueAttributeGroup()
		{
            $data_array=array();
			foreach(LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid::getOptionAttributeGroup() as $k=>$v){
               $data_array[]=array('value'=>$k,'label'=>$v);		
			}
            return($data_array);

		}
		

}