<?php

class LWM_CustomizeProduct_Block_Productattribute extends Mage_Core_Block_Template
{
	protected $_productattributetype;
	protected $_productattributeBlock;
	protected $_productattributeModel;
	public $requireOptionvalue=array();
	protected $_cartBuyRequest;
	protected $_product;
	/**
     * Check if product has required options
     *
     * @return bool
     */
    public function hasRequiredOptions()
    {
        //return $this->getProduct()->getTypeInstance(true)->hasRequiredOptions($this->getProduct());
		return false;
    }
	/**
     * Retrieve product object
     *
     * @return Mage_Catalog_Model_Product
     */
    public function getProduct()
    {
        if (!$this->_product) {
            if (Mage::registry('current_product')) {
                $this->_product = Mage::registry('current_product');
            } else {
                $this->_product = Mage::getSingleton('catalog/product');
            }
        }
        return $this->_product;
    }
	public function getcartBuyRequest(){
		if (!$this->_cartBuyRequest){
			$cartBuyRequest = Mage::app()->getFrontController()->getAction()->getFullActionName();
			if($cartBuyRequest=='checkout_cart_configure'){
			$id = (int) Mage::app()->getRequest()->getParam('id');
				if($id){
					$this->_cartBuyRequest = Mage::getSingleton('checkout/cart')->getQuote()->getItemById($id)->getBuyRequest();
				}else{
					$this->_cartBuyRequest='None';
				}
			}else{
				$this->_cartBuyRequest='None';
			}
		}
		return $this->_cartBuyRequest;
	}
   /**
     * Retrieve product object
     *
     * @return LWM_CustomizeProduct_Model_Productattribute
     */
    public function getProductattributetype()
    {
        if (!$this->_productattributetype) {
                $this->_productattributetype = Mage::registry('current_product')->getData('customize_product_design');
        }
        return $this->_productattributetype;
    }
	public function getProductattributeDetails(){
		if( $this->_productattributetype){
		$collection=Mage::getSingleton('customizeproduct/producttype')->getCollection();
		$collection->addFieldToFilter('ptype_id', $this->_productattributetype);
		foreach($collection as $data){
		  return  $data;
	    }
		}
		return false;
	}
	public function getProductattributeByType(){
		$this->getProductattributetype();
		if( $this->_productattributetype){
		$collection=Mage::getSingleton('customizeproduct/productattribute')->getCollection();
		$collection->addFieldToFilter('ptype_id', $this->_productattributetype);
		return $collection;
		}
		return false;
	}
	public function getProductattributeSortByImage(){
		$this->getProductattributetype();
		if( $this->_productattributetype){
			$collection=Mage::getSingleton('customizeproduct/productattribute')->getCollection();
			$collection->addFieldToFilter('ptype_id', $this->_productattributetype);
			$collection->getSelect()->order('sort_order', 'ASC');
			return $collection;
		}
		return false;
	}
	public function getProductattributeoptionBlock(){
		if(!$this->_productattributeBlock){
			$this->_productattributeBlock=$this->getLayout()->createBlock('customizeproduct/productattribute_options');
			$this->_productattributeBlock->addOptionRenderer('text','customizeproduct/productattribute_options_type_text','customizeproduct/productattribute/options/type/text.phtml');
			$this->_productattributeBlock->addOptionRenderer('file','customizeproduct/productattribute_options_type_file','customizeproduct/productattribute/options/type/file.phtml');
			$this->_productattributeBlock->addOptionRenderer('select','customizeproduct/productattribute_options_type_select','customizeproduct/productattribute/options/type/select.phtml');
			$this->_productattributeBlock->addOptionRenderer('selection','customizeproduct/productattribute_options_type_selection','customizeproduct/productattribute/options/type/selection.phtml');
			$this->_productattributeBlock->addOptionRenderer('date','customizeproduct/productattribute_options_type_select','customizeproduct/productattribute/options/type/date.phtml');
		}
		return $this->_productattributeBlock;
	}
    public function getProductAttributeOptionHtml(LWM_CustomizeProduct_Model_Productattribute $productattribute){
		$this->getProductattributeoptionBlock()->setProductattribute($productattribute);
	    $buyRequest=$this->getcartBuyRequest();
	    if($buyRequest!='None'){
			 $optionsvalue=Mage::helper('customizeproduct')->prepareProductAttributeOptions($productattribute,$buyRequest);
		}
		return $this->getProductattributeoptionBlock()->setTemplate("customizeproduct/productattribute/options.phtml")->toHtml();
	}
	public function getRequireField(){
		return $this->getProductattributeoptionBlock()->getRequiedOption();
	}
}