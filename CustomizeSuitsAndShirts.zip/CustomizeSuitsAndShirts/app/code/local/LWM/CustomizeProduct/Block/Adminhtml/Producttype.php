<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the block Product type for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Block_Adminhtml_Producttype extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_producttype";
	$this->_blockGroup = "customizeproduct";
	$this->_headerText = Mage::helper("customizeproduct")->__("Product Type Manager");
	$this->_addButtonLabel = Mage::helper("customizeproduct")->__("Add New Item");
	parent::__construct();
	
	}

}