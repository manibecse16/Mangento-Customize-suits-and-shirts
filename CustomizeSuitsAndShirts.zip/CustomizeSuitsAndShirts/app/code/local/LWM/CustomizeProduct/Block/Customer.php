<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the customer size option block
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Block_Customer extends Mage_Core_Block_Template
{
   public function getMeasurementSize($customer_id,$type){
	   $collection = Mage::getModel("customizeproduct/measurement")->getCollection();
	   $collection->addFieldToFilter( 'customer_id', $customer_id );
	   $collection->addFieldToFilter( 'measurement_type', $type )->getFirstItem();
	   
	   foreach($collection as $data){
		  return  $data;
	    }
	   return false;
   }
   public function getPantSize($customer_id){
	   $collection = Mage::getModel("customizeproduct/pantsize")->getCollection();
	   $collection->addFieldToFilter('customer_id', $customer_id)->getFirstItem();
	   foreach($collection as $data){
		  return  $data;
	    }
	   return false;
   }
}