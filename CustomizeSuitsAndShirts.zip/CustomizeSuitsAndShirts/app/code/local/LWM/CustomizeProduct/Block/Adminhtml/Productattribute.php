<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the block Product attribute for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Block_Adminhtml_Productattribute extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_productattribute";
	$this->_blockGroup = "customizeproduct";
	$this->_headerText = Mage::helper("customizeproduct")->__("Product Type Attribute Manager");
	$this->_addButtonLabel = Mage::helper("customizeproduct")->__("Add New Attribute");
	parent::__construct();
	
	}

}