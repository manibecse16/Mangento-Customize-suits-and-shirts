<?php

class LWM_CustomizeProduct_Block_Productattribute_Wrapper extends Mage_Core_Block_Template
{
	
}	