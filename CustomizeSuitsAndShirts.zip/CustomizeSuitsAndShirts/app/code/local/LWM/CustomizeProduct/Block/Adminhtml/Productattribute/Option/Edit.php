<?php
	
class LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Option_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
		public function __construct()
		{

				parent::__construct();
				$this->_objectId = "ptype_attribute_id";
				$this->_blockGroup = "customizeproduct";
				$this->_controller = "adminhtml_productattribute";
				$this->_updateButton("save", "label", Mage::helper("customizeproduct")->__("Save Item"));
				$this->_updateButton("delete", "label", Mage::helper("customizeproduct")->__("Delete Item"));

				$this->_addButton("saveandcontinue", array(
					"label"     => Mage::helper("customizeproduct")->__("Save And Continue Edit"),
					"onclick"   => "saveAndContinueEdit()",
					"class"     => "save",
				), -100);



				$this->_formScripts[] = "

							function saveAndContinueEdit(){
								editForm.submit($('edit_form').action+'back/edit/');
							}
						";
		}

		public function getHeaderText()
		{
				if( Mage::registry("productattribute_data") && Mage::registry("productattribute_data")->getId() ){

				    return Mage::helper("customizeproduct")->__("Edit Item '%s'", $this->htmlEscape(Mage::registry("productattribute_data")->getPtypeAttributeName()));

				} 
				else{

				     return Mage::helper("customizeproduct")->__("Add Item");

				}
		}
}