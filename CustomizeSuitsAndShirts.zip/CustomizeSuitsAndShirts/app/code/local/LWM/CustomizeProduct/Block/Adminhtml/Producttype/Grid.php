<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Grid Product attribute for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Block_Adminhtml_Producttype_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

		public function __construct()
		{
				parent::__construct();
				$this->setId("producttypeGrid");
				$this->setDefaultSort("ptype_id");
				$this->setDefaultDir("DESC");
				$this->setSaveParametersInSession(true);
		}

		protected function _prepareCollection()
		{
				$collection = Mage::getModel("customizeproduct/producttype")->getCollection();
				$this->setCollection($collection);
				return parent::_prepareCollection();
		}
		protected function _prepareColumns()
		{
				$this->addColumn("ptype_id", array(
				"header" => Mage::helper("customizeproduct")->__("ID"),
				"align" =>"right",
				"width" => "50px",
			    "type" => "number",
				"index" => "ptype_id",
				));
                
				$this->addColumn("ptype_name", array(
				"header" => Mage::helper("customizeproduct")->__("Name"),
				"index" => "ptype_name",
				));
			$this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV')); 
			$this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

				return parent::_prepareColumns();
		}

		public function getRowUrl($row)
		{
			   return $this->getUrl("*/*/edit", array("id" => $row->getId()));
		}
       static public function getValueProductOptionValue()
		{
            $data_array=array();
			$collection = Mage::getModel("customizeproduct/producttype")->getCollection();
			foreach($collection as $value){
               $data_array[$value->getId()]=$value->getPtypeName();		
			}
            return($data_array);

		}
        static public function getValueProductOptionType()
		{
            $data_array=array();
			$collection = Mage::getModel("customizeproduct/producttype")->getCollection();
			foreach($collection as $value){
               $data_array[]=array('value'=>$value->getId(),'label'=>$value->getPtypeName());		
			}
            return($data_array);

		}
		
		protected function _prepareMassaction()
		{
			$this->setMassactionIdField('ptype_id');
			$this->getMassactionBlock()->setFormFieldName('ptype_ids');
			$this->getMassactionBlock()->setUseSelectAll(true);
			$this->getMassactionBlock()->addItem('remove_producttype', array(
					 'label'=> Mage::helper('customizeproduct')->__('Remove Producttype'),
					 'url'  => $this->getUrl('*/adminhtml_producttype/massRemove'),
					 'confirm' => Mage::helper('customizeproduct')->__('Are you sure?')
				));
			return $this;
		}
			

}