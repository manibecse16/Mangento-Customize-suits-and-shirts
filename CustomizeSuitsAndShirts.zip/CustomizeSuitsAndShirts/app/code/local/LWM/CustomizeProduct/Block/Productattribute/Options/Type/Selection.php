<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magento.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magento.com for more information.
 *
 * @category    Mage
 * @package     Mage_Catalog
 * @copyright  Copyright (c) 2006-2016 X.commerce, Inc. and affiliates (http://www.magento.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * Product options text type block
 *
 * @category   Mage
 * @package    Mage_Catalog
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class LWM_CustomizeProduct_Block_Productattribute_Options_Type_Selection
    extends LWM_CustomizeProduct_Block_Productattribute_Options_Abstract
{
    /**
     * Return html for control element
     *
     * @return string
     */
    public function getValuesHtml()
    {
        $_option = $this->getOption();
		$valuehtml='';
		$attribute_id=$_option->getPtypeAttributeId();
        $configValue = $this->getProductattribute()->getPreconfiguredValues()->getData('options/' .$attribute_id."/options/". $_option->getId());
        $store = $this->getProductattribute()->getStore();
        if ($_option->getType() == LWM_CustomizeProduct_Model_Productattribute_Option::OPTION_TYPE_IMAGE
            || $_option->getType() == LWM_CustomizeProduct_Model_Productattribute_Option::OPTION_TYPE_PIMAGE) {
            $require = ($_option->getIsRequire()) ? ' required-entry' : '';
            $extraParams = '';
            $select = $this->getLayout()->createBlock('core/html_select')
                ->setData(array(
                    'id' => 'selection_'.$_option->getId(),
                    'class' => $require.' product-attribute-option selection'
                ));
				
			if($_option->getType() == LWM_CustomizeProduct_Model_Productattribute_Option::OPTION_TYPE_PIMAGE) {
			 $configValue = $this->getProductattribute()->getPreconfiguredValues()->getData('options/' .$attribute_id."/options/".$_option->getId()."/value");
			 $patternValue=$this->getProductattribute()->getPreconfiguredValues()->getData('options/' .$attribute_id."/options/".$_option->getId()."/attrPattern");
			 $attrPatternValues=array(1=>"Left Side",2=>"Right Side",3=>"Both Side");
			// $checked = $patternValue == $htmlValue ? 'checked' : '';	
			 
            $select->setName('productattributeoptions['.$_option->getPtypeAttributeId().'][options]['.$_option->getId().'][value]')
                    ->addOption('', $this->__('-- Please Select --'));				
            /*Pattern load*/
			$currentPattern=($patternValue)?$patternValue:1;
			 $valuehtml.='<div class="pattern-view">';
			  foreach($attrPatternValues as $key=>$value){
				   $checked = $currentPattern == $key ? 'checked' : '';
                   $valuehtml.='<span>'.$value.'</span><input name="productattributeoptions['.$_option->getPtypeAttributeId().'][options]['.$_option->getId().'][attrPattern]" value="'.$key.'" onclick="stitchImage.loadStitchView()" '.$checked.' type="radio">';				   
			  }
			   $valuehtml.='</div>';
			}else{
				$select->setName('productattributeoptions['.$_option->getPtypeAttributeId().'][options]['.$_option->getId().']')
                    ->addOption('', $this->__('-- Please Select --'));
			}
			$imagepath= Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'customizeproduct/';
            $valuehtml.="<ul class='pattribute-imgs'>"; 			
            foreach ($_option->getValues() as $_value) {
                $priceStr = $this->_formatPrice(array(
                    'is_percent'    => ($_value->getPriceType() == 'percent'),
                    'pricing_value' => $_value->getPrice(($_value->getPriceType() == 'percent'))
                ), false);
                $select->addOption(
                    $_value->getOptionTypeId(),
                    $_value->getTitle() . ' ' . $priceStr . '',
                    array('price' => $this->helper('core')->currencyByStore($_value->getPrice(true), $store, false))
                );
				$activeClass=$configValue == $_value->getOptionTypeId() ? 'active' : '';
				$simage=($_value->getOptionImageSmall())?$imagepath.$_value->getOptionImageSmall():$imagepath."option.jpg";
				$valuehtml.='<li class="'.$activeClass.'" data-value="'.$_value->getOptionTypeId().'" data-attr="'.$_option->getPtypeAttributeId().'" data-option="'.$_option->getId().'" data-bg-image="'.str_replace(DS,"/",$_value->getOptionImageBg()).'" data-bg-image-left="'.str_replace(DS,"/",$_value->getOptionImageLeftSide()).'" data-bg-image-right="'.str_replace(DS,"/",$_value->getOptionImageRightSide()).'" data-bg-image-both="'.str_replace(DS,"/",$_value->getOptionImageBothSide()).'" data-text="'.$_value->getTitle().'" data-fld="selection" >
				<a class="a_cursor" href="javascript:void(0);" title="'.$_value->getTitle().'" alt="'.$_value->getTitle().'">
				<div class="product-attribute-img"><img src="'.$simage.'"  /></div>
				<span>'.$_value->getTitle().'</span></a></li>';
            }
			
			$valuehtml.="</ul>"; 
            if (!$this->getSkipJsReloadPrice()) {
                $extraParams .= ' onchange="opConfig'.$_option->getPtypeAttributeId().'.reloadPrice()"';
            }
            $select->setExtraParams($extraParams);

            if ($configValue) {
                $select->setValue($configValue);
            }

            return $valuehtml.$select->getHtml();
        }

       
    }

}
