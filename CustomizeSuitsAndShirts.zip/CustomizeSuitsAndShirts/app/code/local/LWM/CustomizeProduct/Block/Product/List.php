<?php
class LWM_CustomizeProduct_Block_Product_List extends Mage_Catalog_Block_Product_List
{
	/**
     * Retrieve url for add product to cart
     * Will return product view page URL if product has required options
     *
     * @param Mage_Catalog_Model_Product $product
     * @param array $additional
     * @return string
     */
    public function getAddToCartUrl($product, $additional = array())
    {
		 $customizevalue=$product->getData('customize_product_design');
        if (!$product->getTypeInstance(true)->hasRequiredOptions($product)) {
			if(!$customizevalue){
               return $this->helper('checkout/cart')->getAddUrl($product, $additional);
			}else{
				 return $this->getProductUrl($product, $additional);
			}
        }
        $additional = array_merge(
            $additional,
            array(Mage_Core_Model_Url::FORM_KEY => $this->_getSingletonModel('core/session')->getFormKey())
        );
        if (!isset($additional['_escape'])) {
            $additional['_escape'] = true;
        }
        if (!isset($additional['_query'])) {
            $additional['_query'] = array();
        }
        $additional['_query']['options'] = 'cart';
        return $this->getProductUrl($product, $additional);
    }
}