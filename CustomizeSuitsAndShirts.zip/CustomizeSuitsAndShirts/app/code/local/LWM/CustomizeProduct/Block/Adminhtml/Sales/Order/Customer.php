<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the customer size option block
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Block_Adminhtml_Sales_Order_Customer extends Mage_Core_Block_Template
{
   public function getMeasurementSize($customer_id,$type){
	   $collection = Mage::getModel("customizeproduct/measurement")->getCollection();
	   $collection->addFieldToFilter( 'customer_id', $customer_id );
	   $collection->addFieldToFilter( 'measurement_type', $type )->getFirstItem();
	   
	   foreach($collection as $data){
		  return  $data;
	    }
	   return false;
   }
   public function getPantSize($customer_id){
	   $collection = Mage::getModel("customizeproduct/pantsize")->getCollection();
	   $collection->addFieldToFilter('customer_id', $customer_id)->getFirstItem();
	   foreach($collection as $data){
		  return  $data;
	    }
	   return false;
   }
     protected $order;
    
    public function getOrder() {
        if (is_null($this->order)) {
            if (Mage::registry('current_order')) {
                $order = Mage::registry('current_order');
            }
            elseif (Mage::registry('order')) {
                $order = Mage::registry('order');
            }
            else {
                $order = new Varien_Object();
            }
            $this->order = $order;
        }
		Mage::log(Mage::registry('current_order'),null,"testing.log",true);
        return $this->order;
    }
}