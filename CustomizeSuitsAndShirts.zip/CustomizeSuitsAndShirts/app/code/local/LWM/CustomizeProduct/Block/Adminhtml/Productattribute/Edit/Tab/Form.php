<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Product attribute form for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("customizeproduct_form", array("legend"=>Mage::helper("customizeproduct")->__("Item information")));

				
						$fieldset->addField("ptype_attribute_name", "text", array(
						"label" => Mage::helper("customizeproduct")->__("Name"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "ptype_attribute_name",
						));
									
						 /* $fieldset->addField('ptype_attribute_view', 'select', array(
						'label'     => Mage::helper('customizeproduct')->__('Attribute View'),
						'values'   => LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid::getValueArray4(),
						'name' => 'ptype_attribute_view',
						)); */	
                        $fieldset->addField('ptype_id', 'select', array(
						'label'     => Mage::helper('customizeproduct')->__('Product Type'),
						"class" => "required-entry",
						"required" => true,
						'values'   => LWM_CustomizeProduct_Block_Adminhtml_Producttype_Grid::getValueProductOptionType(),
						'name' => 'ptype_id',
						));								
						 $fieldset->addField('ptype_attribute_pattern', 'select', array(
						'label'     => Mage::helper('customizeproduct')->__('Attribute Pattern'),
						'values'   => LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid::getValueArray5(),
						'name' => 'ptype_attribute_pattern',
						));
						$fieldset->addField("sort_order", "text", array(
						"label" => Mage::helper("customizeproduct")->__("BG Image Sort order"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "sort_order",
						));
						$fieldset->addField('ptype_attribute_group', 'select', array(
						'label'     => Mage::helper('customizeproduct')->__('Attribute Group'),
						'values'   => LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid::getValueAttributeGroup(),
						'name' => 'ptype_attribute_group',
						));
                        $fieldset->addField('ptype_attribute_front_image', 'image', array(
						'label' => Mage::helper('customizeproduct')->__('Front image for pant'),
						'name' => 'ptype_attribute_front_image',
						'note' => 'This is optional you need upload this combine the suit and pant.Pant option first front bg image(*.jpg, *.png, *.gif)',
						));				
				if (Mage::getSingleton("adminhtml/session")->getProductattributeData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getProductattributeData());
					Mage::getSingleton("adminhtml/session")->setProductattributeData(null);
				} 
				elseif(Mage::registry("productattribute_data")) {
				    $form->setValues(Mage::registry("productattribute_data")->getData());
				}
				return parent::_prepareForm();
		}
}
