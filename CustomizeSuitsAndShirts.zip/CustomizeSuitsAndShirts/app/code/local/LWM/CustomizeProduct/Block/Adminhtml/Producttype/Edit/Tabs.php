<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Product type Tabs for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */	
class LWM_CustomizeProduct_Block_Adminhtml_Producttype_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
		public function __construct()
		{
				parent::__construct();
				$this->setId("producttype_tabs");
				$this->setDestElementId("edit_form");
				$this->setTitle(Mage::helper("customizeproduct")->__("Item Information"));
		}
		protected function _beforeToHtml()
		{
				$this->addTab("form_section", array(
				"label" => Mage::helper("customizeproduct")->__("Product Type Information"),
				"title" => Mage::helper("customizeproduct")->__("Product Type Information"),
				"content" => $this->getLayout()->createBlock("customizeproduct/adminhtml_producttype_edit_tab_form")->toHtml(),
				));
				/* $this->addTab("form_section1", array(
				"label" => Mage::helper("customizeproduct")->__("Manage Color Stitch Image"),
				"title" => Mage::helper("customizeproduct")->__("Manage Color Stitch Image"),
				"content" => $this->getLayout()->createBlock("customizeproduct/adminhtml_producttype_edit_tab_colorimage")->toHtml(),
				)); */
				return parent::_beforeToHtml();
		}

}
