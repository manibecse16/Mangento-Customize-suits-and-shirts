<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magento.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magento.com for more information.
 *
 * @category    Mage
 * @package     Mage_Catalog
 * @copyright  Copyright (c) 2006-2016 X.commerce, Inc. and affiliates (http://www.magento.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * Product options block
 *
 * @category   Mage
 * @package    Mage_Catalog
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class LWM_CustomizeProduct_Block_Productattribute_Options extends Mage_Core_Block_Template
{
    protected $_productattribute;

    protected $_optionRenders = array();

    public function __construct()
    {
        parent::__construct();
        $this->addOptionRenderer(
            'default',
            'customizeproduct/productattribute_options_type_default',
            'customizeproduct/productattribute/options/type/default.phtml'
        );
    }

    /**
     * Retrieve product object
     *
     * @return LWM_CustomizeProduct_Model_Productattribute
     */
    public function getProductattribute()
    {
        if (!$this->_productattribute) {
                $this->_productattribute = Mage::getSingleton('customizeproduct/productattribute');
        }
		
        return $this->_productattribute;
    }

    /**
     * Set productattribute object
     *
     * @param LWM_CustomizeProduct_Model_Productattribute $productattribute
     * @return LWM_CustomizeProduct_Block_Productattribute_Options
     */
    public function setProductattribute(LWM_CustomizeProduct_Model_Productattribute $productattribute = null)
    {
        $this->_productattribute = $productattribute;
        return $this;
    }

    /**
     * Add option renderer to renderers array
     *
     * @param string $type
     * @param string $block
     * @param string $template
     * @return LWM_CustomizeProduct_Block_Productattribute_Options
     */
    public function addOptionRenderer($type, $block, $template)
    {
        $this->_optionRenders[$type] = array(
            'block' => $block,
            'template' => $template,
            'renderer' => null
        );
        return $this;
    }

    /**
     * Get option render by given type
     *
     * @param string $type
     * @return array
     */
    public function getOptionRender($type)
    {
        if (isset($this->_optionRenders[$type])) {
            return $this->_optionRenders[$type];
        }

        return $this->_optionRenders['default'];
    }

    public function getGroupOfOption($type)
    {
        $group = Mage::getSingleton('customizeproduct/productattribute_option')->getGroupByType($type);

        return $group == '' ? 'default' : $group;
    }

    /**
     * Get product options
     *
     * @return array
     */
    public function getOptions()
    {
		$this->getProductattribute()->loadOptions();
        return $this->getProductattribute()->getOptions();
    }

    public function hasOptions()
    {
        if ($this->getOptions()) {
            return true;
        }
        return false;
    }

    /**
     * Get price configuration
     *
     * @param LWM_CustomizeProduct_Model_Productattribute_Option_Value|LWM_CustomizeProduct_Model_Productattribute_Option $option
     * @return array
     */
    protected function _getPriceConfiguration($option)
    {
        $data = array();
        $data['price']      = Mage::helper('core')->currency($option->getPrice(true), false, false);
        $data['oldPrice']   = Mage::helper('core')->currency($option->getPrice(false), false, false);
        $data['priceValue'] = $option->getPrice(false);
        $data['type']       = $option->getPriceType();
        $data['excludeTax'] = $price = Mage::helper('tax')->getPrice($option->getProductattribute(), $data['price'], false);
        $data['includeTax'] = $price = Mage::helper('tax')->getPrice($option->getProductattribute(), $data['price'], true);
        return $data;
    }

    /**
     * Get json representation of
     *
     * @return string
     */
    public function getJsonConfig()
    {
        $config = array();

        foreach ($this->getOptions() as $option) {
            /* @var $option LWM_CustomizeProduct_Model_Productattribute_Option */
            $priceValue = 0;
            if ($option->getGroupByType() == LWM_CustomizeProduct_Model_Productattribute_Option::OPTION_GROUP_SELECT||$option->getGroupByType() == LWM_CustomizeProduct_Model_Productattribute_Option::OPTION_GROUP_SELECTION) {
                $_tmpPriceValues = array();
                foreach ($option->getValues() as $value) {
                    /* @var $value LWM_CustomizeProduct_Model_Productattribute_Option_Value */
                    $id = $value->getId();
                    $_tmpPriceValues[$id] = $this->_getPriceConfiguration($value);
                }
                $priceValue = $_tmpPriceValues;
            } else {
                $priceValue = $this->_getPriceConfiguration($option);
            }
            $config[$option->getId()] = $priceValue;
        }

        return Mage::helper('core')->jsonEncode($config);
    }
    public function getRequiedOption(){
		 $config = array();

        foreach ($this->getOptions() as $option) {
			if($option->getIsRequire()){
				return true;
			}
		}	
	}
    /**
     * Get option html block
     *
     * @param LWM_CustomizeProduct_Model_Productattribute_Option $option
     */
    public function getOptionHtml(LWM_CustomizeProduct_Model_Productattribute_Option $option)
    {
		
        $renderer = $this->getOptionRender(
            $this->getGroupOfOption($option->getType())
        );

        if (is_null($renderer['renderer'])) {
            $renderer['renderer'] = $this->getLayout()->createBlock($renderer['block'])
                ->setTemplate($renderer['template']);
        }
		//print_r($renderer['renderer']);
        return $renderer['renderer']
            ->setProductattribute($this->getProductattribute())
            ->setOption($option)
            ->toHtml();
    }
}
