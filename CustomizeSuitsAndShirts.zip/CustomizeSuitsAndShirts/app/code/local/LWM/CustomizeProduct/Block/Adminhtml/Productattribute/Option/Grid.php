<?php

class LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Option_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

		public function __construct()
		{
				parent::__construct();
				$this->setId("productattributeoptionGrid");
				$this->setDefaultSort("option_id");
				$this->setDefaultDir("DESC");
				$this->setSaveParametersInSession(true);
		}

		protected function _prepareCollection()
		{
				$collection = Mage::getModel("customizeproduct/productattribute_option")->getCollection();
				$this->setCollection($collection);
				return parent::_prepareCollection();
		}
		protected function _prepareColumns()
		{
				$this->addColumn("option_id", array(
				"header" => Mage::helper("customizeproduct")->__("ID"),
				"align" =>"right",
				"width" => "50px",
			    "type" => "number",
				"index" => "option_id",
				));
                
				$this->addColumn("ptype_attribute_name", array(
				"header" => Mage::helper("customizeproduct")->__("Name"),
				"index" => "ptype_attribute_name",
				));
						$this->addColumn('ptype_attribute_view', array(
						'header' => Mage::helper('customizeproduct')->__('Attribute View'),
						'index' => 'ptype_attribute_view',
						'type' => 'options',
						'options'=>LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid::getOptionArray4(),				
						));
						
						$this->addColumn('ptype_attribute_pattern', array(
						'header' => Mage::helper('customizeproduct')->__('Attribute Pattern'),
						'index' => 'ptype_attribute_pattern',
						'type' => 'options',
						'options'=>LWM_CustomizeProduct_Block_Adminhtml_Productattribute_Grid::getOptionArray5(),				
						));
						
			$this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV')); 
			$this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

				return parent::_prepareColumns();
		}

		public function getRowUrl($row)
		{
			   return $this->getUrl("*/*/edit", array("id" => $row->getId()));
		}


		
		protected function _prepareMassaction()
		{
			$this->setMassactionIdField('ptype_attribute_id');
			$this->getMassactionBlock()->setFormFieldName('ptype_attribute_ids');
			$this->getMassactionBlock()->setUseSelectAll(true);
			$this->getMassactionBlock()->addItem('remove_productattribute', array(
					 'label'=> Mage::helper('customizeproduct')->__('Remove Productattribute'),
					 'url'  => $this->getUrl('*/adminhtml_productattribute/massRemove'),
					 'confirm' => Mage::helper('customizeproduct')->__('Are you sure?')
				));
			return $this;
		}
		
		

}