<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Product type form for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */	
class LWM_CustomizeProduct_Block_Adminhtml_Producttype_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("customizeproduct_form", array("legend"=>Mage::helper("customizeproduct")->__("Item information")));

				
						$fieldset->addField("ptype_name", "text", array(
						"label" => Mage::helper("customizeproduct")->__("Name"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "ptype_name",
						));
									
						$fieldset->addField('ptype_base_front_image', 'image', array(
						'label' => Mage::helper('customizeproduct')->__('Stitch Base Front Image'),
						'name' => 'ptype_base_front_image',
						'note' => '(*.jpg, *.png, *.gif)',
						));				
						/* $fieldset->addField('ptype_base_back_image', 'image', array(
						'label' => Mage::helper('customizeproduct')->__('Stitch Base Back Image'),
						'name' => 'ptype_base_back_image',
						'note' => '(*.jpg, *.png, *.gif)',
						)); */

				if (Mage::getSingleton("adminhtml/session")->getProducttypeData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getProducttypeData());
					Mage::getSingleton("adminhtml/session")->setProducttypeData(null);
				} 
				elseif(Mage::registry("producttype_data")) {
				    $form->setValues(Mage::registry("producttype_data")->getData());
				}
				return parent::_prepareForm();
		}
}
