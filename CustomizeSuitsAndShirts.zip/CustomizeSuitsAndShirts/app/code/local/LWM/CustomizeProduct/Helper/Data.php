<?php
class LWM_CustomizeProduct_Helper_Data extends Mage_Core_Helper_Abstract
{
	public function getOptionsPath($groupId, $optionId = false, $valueId = false) {
        return Mage::getBaseDir('media')  . DS . 'customizeproduct'. DS . ($groupId ? $groupId : 'options') . DS . ($optionId ? $optionId . DS : '') . ($valueId ? $valueId . DS : '');
    } 
	public function deleteOptionFile($groupId, $optionId, $valueId = false, $fileName = '') {
        $dir = $this->getOptionsPath($groupId, $optionId, $valueId);
        if ($fileName) {
            if (file_exists($dir . $fileName)) {
                unlink($dir . $fileName);
                $isEmpty = true;
                if (is_dir($dir)) {
                    $objects = scandir($dir);
                    foreach ($objects as $object) {
                        if ($object=='.' || $object == '..') continue;
                        if (filetype($dir . DS . $object) == "dir") {
                            if (file_exists($dir . $object . DS . $fileName)) unlink($dir . $object . DS . $fileName);
                            continue;
                        }
                        $isEmpty = false;
                    }
                }
                // if empty - remove folder
                if ($isEmpty) $this->deleteFolder($dir);
                return true;
            } else {
                return false;
            }
        } else {
            $this->deleteFolder($dir);
        }
    }
	public function deleteFolder($dir) {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (filetype($dir . DS . $object) == "dir") {
                        $this->deleteFolder($dir . DS . $object);
                    } else {
                        unlink($dir . DS . $object);
                    }
                }
            }
            reset($objects);
            rmdir($dir);
        }
    }
	public function getColorAttributeOption(){
		$attribute = Mage::getModel('eav/entity_attribute')->loadByCode(Mage_Catalog_Model_Product::ENTITY, 'color');
		/** @var $attribute Mage_Eav_Model_Entity_Attribute */
		$valuesCollection = Mage::getResourceModel('eav/entity_attribute_option_collection')
		->setAttributeFilter($attribute->getId())
		->setStoreFilter(0, false);
		return $valuesCollection;
	}
	public function getProducttypedetails($id){
		$collection = Mage::getModel("customizeproduct/producttype")->getCollection()->addFieldToFilter('ptype_id',$id);
//Mage::log($collection,null,"testing.log",true);		
		foreach($collection  as $data){
			return $data;
		}
		return false;
	}
	public function uploadCartImage($img,$name){
		$data=array();
		if($img){
		$img = str_replace('data:image/png;base64,', '', $img);
		$img = str_replace(' ', '+', $img);
		$data = base64_decode($img);
		$time=mktime();
		$file = Mage::getBaseDir('media').DS."customizeproduct".DS."cart".DS.$name.$time. ".png";
		$success = file_put_contents($file, $data);
		$data=array('status'=>$success,"filelocation"=>"customizeproduct/cart/".$name.$time.".png");
		return $data;
		}
       return false;
	}
	public function moveCartImage($file){
		$time=mktime();
		$newfile = Mage::getBaseDir('media').DS."customizeproduct".DS."order".DS.$time. ".png";  
		if ( copy($file, $newfile) ) {
			return "customizeproduct/order/".$time. ".png";
		}	
		return false;
	}
	public function getRange($from,$to) {
		$array_range = array();
		$numbers = range($from, $to, 0.25);
		foreach ($numbers as $number) {
			$array_range["$number"] = $number;
		}
		return $array_range;
		
	}
	public function generateSelect($name,$value,$id,$from,$to) {
		$array_range = array();
		$numbers = range($from, $to, 0.25);
		$selectHtml='<select name="'.$name.'" class="required-entry" id="'.$id.'">';
		$selectHtml.='<option value="">--Select--</option>';
		foreach ($numbers as $number) {
			$array_range["$number"] = $number;
			if($number==$value){
				$selectHtml.='<option value="'.$number.'" selected="selected">'.$number.'"</option>';
			}else{
				$selectHtml.='<option value="'.$number.'">'.$number.'"</option>';
			}
			
			
		}
		$selectHtml.='</select>';
		return $selectHtml;
		
	}
	 /**
     * Prepares productattribute options by buyRequest: retrieves values and assigns them as default.
     * Also parses and adds product management related values - e.g. qty
     *
     * @param  LWM_CustomizeProduct_Model_Productattribute $productattribute
     * @param  Varien_Object $buyRequest
     * @return LWM_CustomizeProduct_Helper_Data
     */
    public function prepareProductAttributeOptions($productattribute, $buyRequest)
    {
        $optionValues = $productattribute->processBuyRequest($buyRequest);
        $optionValues->setQty($buyRequest->getQty());
        $productattribute->setPreconfiguredValues($optionValues);

        return $this;
    }
}
	 
