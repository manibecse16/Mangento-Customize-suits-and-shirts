<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Product type model for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
abstract class LWM_CustomizeProduct_Model_Cart_Abstract
{
	 /**
     * Process modes
     *
     * Lite validation - only received options are validated
     */
    const PROCESS_MODE_LITE = 'lite';
     /**
     * Item options prefix
     */
    const OPTION_PREFIX = 'poption_';
    /**
     * Product model instance
     *
     * @deprecated if use as singleton
     * @var LWM_CustomizeProduct_Model_Productattribute
     */
    protected $_productattribute;

    /**
     * Specify type instance Productattribute
     *
     * @param   LWM_CustomizeProduct_Model_Productattribute $productattribute
     * @return  Mage_Catalog_Model_Product_Type_Abstract
     */
    public function setProductattribute($productattribute)
    {
        $this->_productattribute = $productattribute;
        return $this;
    }
	
	/**
     * Retrieve catalog product object
     *
     * @param LWM_CustomizeProduct_Model_Productattribute $product
     * @return LWM_CustomizeProduct_Model_Productattribute
     */
    public function getProductattribute($productattribute = null)
    {
        if (is_object($productattribute)) {
            return $productattribute;
        }
        return $this->_productattribute;
    }
   /**
     * Process custom defined options for productattribute
     *
     * @param Varien_Object $buyRequest
     * @param LWM_CustomizeProduct_Model_Productattribute $productattribute
     * @param 
     * @return array
     */
    protected function _prepareOptions(Varien_Object $buyRequest, $productattribute, $processMode)
    {
        $transport = new StdClass;
        $transport->options = array();
        foreach ($this->getProductattribute($productattribute)->getOptions() as $_option) {
			$attrPattern='';
			if($_option->getType()!='pimage'){
				$buyoptions=$buyRequest->getOptions();
			}else{
			   	$buyoptions=$buyRequest->getOptions();
				$buyoptions[$_option->getId()]=$buyoptions[$_option->getId()]['value'];
				if(isset($buyoptions[$_option->getId()]['attrPattern'])){
					if($buyoptions[$_option->getId()]['attrPattern']==1){
						$attrPattern="Left Side";
					}elseif($buyoptions[$_option->getId()]['attrPattern']==2){
						$attrPattern="Right Side";
					}elseif($buyoptions[$_option->getId()]['attrPattern']==3){
						$attrPattern="Both Side";
					}
				}
			}
            /* @var $_option LWM_CustomizeProduct_Model_Productattribute_Option */
            $group = $_option->groupFactory($_option->getType())
                ->setOption($_option)
                ->setProductattribute($this->getProductattribute($productattribute))
                ->setRequest($buyRequest)
                ->setProcessMode($processMode)
                ->validateUserValue($buyoptions);
            $preparedValue = $group->prepareForCart();
			if ($preparedValue !== null) {
                $transport->options[$_option->getId()]['preparedValue'] = $preparedValue;
				$transport->options[$_option->getId()]['label']=$_option->getTitle();
				$transport->options[$_option->getId()]['value']= $group->getFormattedOptionValue($preparedValue);
				$transport->options[$_option->getId()]['print_value']= $group->getPrintableOptionValue($preparedValue);
				$transport->options[$_option->getId()]['attrPattern']=$attrPattern;
            }
			
        }
        return $transport->options;
    }
}	