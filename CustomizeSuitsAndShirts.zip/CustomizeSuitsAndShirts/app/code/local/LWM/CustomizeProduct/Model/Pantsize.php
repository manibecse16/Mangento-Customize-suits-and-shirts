<?php

class LWM_CustomizeProduct_Model_Pantsize extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("customizeproduct/pantsize");

    }

}
	 