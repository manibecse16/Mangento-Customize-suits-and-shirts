<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magento.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magento.com for more information.
 *
 * @category    Mage
 * @package     Mage_Catalog
 * @copyright  Copyright (c) 2006-2016 X.commerce, Inc. and affiliates (http://www.magento.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Catalog product option model
 *
 * @method LWM_CustomizeProduct_Model_Mysql4_Productattribute_Option _getResource()
 * @method LWM_CustomizeProduct_Model_Mysql4_Productattribute_Option getResource()
 * @method int getProductattributeId()
 * @method LWM_CustomizeProduct_Model_Productattribute_Option setProductId(int $value)
 * @method string getType()
 * @method LWM_CustomizeProduct_Model_Productattribute_Option setType(string $value)
 * @method int getIsRequire()
 * @method LWM_CustomizeProduct_Model_Productattribute_Option setIsRequire(int $value)
 * @method string getSku()
 * @method LWM_CustomizeProduct_Model_Productattribute_Option setSku(string $value)
 * @method int getMaxCharacters()
 * @method LWM_CustomizeProduct_Model_Productattribute_Option setMaxCharacters(int $value)
 * @method string getFileExtension()
 * @method LWM_CustomizeProduct_Model_Productattribute_Option setFileExtension(string $value)
 * @method int getImageSizeX()
 * @method LWM_CustomizeProduct_Model_Productattribute_Option setImageSizeX(int $value)
 * @method int getImageSizeY()
 * @method LWM_CustomizeProduct_Model_Productattribute_Option setImageSizeY(int $value)
 * @method int getSortOrder()
 * @method LWM_CustomizeProduct_Model_Productattribute_Option setSortOrder(int $value)
 *
 * @category    Mage
 * @package     Mage_Catalog
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class LWM_CustomizeProduct_Model_Productattribute_Option extends Mage_Core_Model_Abstract
{
    /**
     * Option group text
     */
    const OPTION_GROUP_TEXT   = 'text';

    /**
     * Option group file
     */
    const OPTION_GROUP_FILE   = 'file';

    /**
     * Option group select
     */
    const OPTION_GROUP_SELECT = 'select';

	 /**
     * Option group select
     */
    const OPTION_GROUP_SELECTION = 'selection';

    /**
     * Option group date
     */
    const OPTION_GROUP_DATE   = 'date';

    /**
     * Option type field
     */
    const OPTION_TYPE_FIELD     = 'field';

    /**
     * Option type area
     */
    const OPTION_TYPE_AREA      = 'area';

    /**
     * Option group file
     */
    const OPTION_TYPE_FILE      = 'file';

    /**
     * Option type drop down
     */
    const OPTION_TYPE_DROP_DOWN = 'drop_down';

    /**
     * Option type radio
     */
    const OPTION_TYPE_RADIO     = 'radio';

    /**
     * Option type checkbox
     */
    const OPTION_TYPE_CHECKBOX  = 'checkbox';

    /**
     * Option type multiple
     */
    const OPTION_TYPE_MULTIPLE  = 'multiple';

    /**
     * Option type date
     */
    const OPTION_TYPE_DATE      = 'date';

    /**
     * Option type date/time
     */
    const OPTION_TYPE_DATE_TIME = 'date_time';

    /**
     * Option type time
     */
    const OPTION_TYPE_TIME      = 'time';

	   /**
     * Option type image
     */
    const OPTION_TYPE_IMAGE      = 'image';
	   /**
     * Option type image
     */
    const OPTION_TYPE_PIMAGE      = 'pimage';
    /**
     * Product instance
     *
     * @var LWM_CustomizeProduct_Model_Productattribute
     */
    protected $_productattribute;

    /**
     * Options
     *
     * @var array
     */
    protected $_options = array();

    /**
     * Value instance
     *
     * @var LWM_CustomizeProduct_Model_Productattribute_Option_Value
     */
    protected $_valueInstance;

    /**
     * Values
     *
     * @var array
     */
    protected $_values = array();

    /**
     * Constructor
     */
    protected function _construct()
    {
        $this->_init('customizeproduct/productattribute_option');
    }

    /**
     * Add value of option to values array
     *
     * @param LWM_CustomizeProduct_Model_Productattribute_Option_Value $value
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function addValue(LWM_CustomizeProduct_Model_Productattribute_Option_Value $value)
    {
        $this->_values[$value->getId()] = $value;
        return $this;
    }

    /**
     * Get value by given id
     *
     * @param int $valueId
     * @return LWM_CustomizeProduct_Model_Productattribute_Option_Value
     */
    public function getValueById($valueId)
    {
        if (isset($this->_values[$valueId])) {
            return $this->_values[$valueId];
        }

        return null;
    }

    /**
     * Get values
     *
     * @return array
     */
    public function getValues()
    {
        return $this->_values;
    }

    /**
     * Retrieve value instance
     *
     * @return LWM_CustomizeProduct_Model_Productattribute_Option_Value
     */
    public function getValueInstance()
    {
        if (!$this->_valueInstance) {
            $this->_valueInstance = Mage::getSingleton('customizeproduct/productattribute_option_value');
        }
        return $this->_valueInstance;
    }

    /**
     * Add option for save it
     *
     * @param array $option
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function addOption($option)
    {
        $this->_options[] = $option;
        return $this;
    }

    /**
     * Get all options
     *
     * @return array
     */
    public function getOptions()
    {
        return $this->_options;
    }

    /**
     * Set options for array
     *
     * @param array $options
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function setOptions($options)
    {
        $this->_options = $options;
        return $this;
    }

    /**
     * Set options to empty array
     *
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function unsetOptions()
    {
        $this->_options = array();
        return $this;
    }

    /**
     * Retrieve product instance
     *
     * @return LWM_CustomizeProduct_Model_Productattribute
     */
    public function getProductattribute()
    {
        return $this->_productattribute;
    }

    /**
     * Set product instance
     *
     * @param LWM_CustomizeProduct_Model_Productattribute $productattribute
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function setProductattribute(LWM_CustomizeProduct_Model_Productattribute $productattribute = null)
    {
        $this->_productattribute = $productattribute;
        return $this;
    }

    /**
     * Get group name of option by given option type
     *
     * @param string $type
     * @return string
     */
    public function getGroupByType($type = null)
    {
        if (is_null($type)) {
            $type = $this->getType();
        }
        $optionGroupsToTypes = array(
            self::OPTION_TYPE_FIELD => self::OPTION_GROUP_TEXT,
            self::OPTION_TYPE_AREA => self::OPTION_GROUP_TEXT,
            self::OPTION_TYPE_FILE => self::OPTION_GROUP_FILE,
            self::OPTION_TYPE_DROP_DOWN => self::OPTION_GROUP_SELECT,
            self::OPTION_TYPE_RADIO => self::OPTION_GROUP_SELECT,
            self::OPTION_TYPE_CHECKBOX => self::OPTION_GROUP_SELECT,
            self::OPTION_TYPE_MULTIPLE => self::OPTION_GROUP_SELECT,
			self::OPTION_TYPE_IMAGE => self::OPTION_GROUP_SELECTION,
			self::OPTION_TYPE_PIMAGE => self::OPTION_GROUP_SELECTION,
            self::OPTION_TYPE_DATE => self::OPTION_GROUP_DATE,
            self::OPTION_TYPE_DATE_TIME => self::OPTION_GROUP_DATE,
            self::OPTION_TYPE_TIME => self::OPTION_GROUP_DATE,
        );

        return isset($optionGroupsToTypes[$type])?$optionGroupsToTypes[$type]:'';
    }

    /**
     * Group model factory
     *
     * @param string $type Option type
     * @return LWM_CustomizeProduct_Model_Productattribute_Option_Group_Abstract
     */
    public function groupFactory($type)
    {
        $group = $this->getGroupByType($type);
        if (!empty($group)) {
            return Mage::getModel('customizeproduct/productattribute_option_type_' . $group);
        }
        Mage::throwException(Mage::helper('catalog')->__('Wrong option type to get group instance.'));
    }

    /**
     * Save options.
     *
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function saveOptions()
    {
        foreach ($this->getOptions() as $option) {

            $this->setData($option)
                ->setData('ptype_attribute_id', $this->getProductattribute()->getId())
                ->setData('store_id', 0);

            if ($this->getData('option_id') == '0') {
                $this->unsetData('option_id');
            } else {
                $this->setId($this->getData('option_id'));
            }
			
            $isEdit = (bool)$this->getId()? true:false;

            if ($this->getData('is_delete') == '1') {
                if ($isEdit) {
                    $this->getValueInstance()->deleteValue($this->getId());
                    $this->deletePrices($this->getId());
                    $this->deleteTitles($this->getId());
                    $this->delete();
                }
            } else {
                if ($this->getData('previous_type') != '') {
                    $previousType = $this->getData('previous_type');

                    /**
                     * if previous option has different group from one is came now
                     * need to remove all data of previous group
                     */
                    if ($this->getGroupByType($previousType) != $this->getGroupByType($this->getData('type'))) {

                        switch ($this->getGroupByType($previousType)) {
                            case self::OPTION_GROUP_SELECT:
								//if($this->getData('type')!=self::OPTION_GROUP_SELECTION){
									$this->unsetData('values');
									if ($isEdit) {
										$this->getValueInstance()->deleteValue($this->getId());
									}
								//}
                                break;
							/* case self::OPTION_GROUP_SELECTION:
                                $this->unsetData('values');
                                if ($isEdit) {
                                    $this->getValueInstance()->deleteValue($this->getId());
                                }
                                break; */	
                            case self::OPTION_GROUP_FILE:
                                $this->setData('file_extension', '');
                                $this->setData('image_size_x', '0');
                                $this->setData('image_size_y', '0');
                                break;
                            case self::OPTION_GROUP_TEXT:
                                $this->setData('max_characters', '0');
                                break;
                            case self::OPTION_GROUP_DATE:
                                break;
                        }
                        if ($this->getGroupByType($this->getData('type')) == self::OPTION_GROUP_SELECT) {
                            $this->setData('sku', '');
                            $this->unsetData('price');
                            $this->unsetData('price_type');
                            if ($isEdit) {
                                $this->deletePrices($this->getId());
                            }
                        }
                    }
                }
                $this->save();            }
        }//eof foreach()
        return $this;
    }
	public function deleteOptions(){
		
		foreach ($this->getOptions() as $option) {
			try{
			$this->setData($option)
                ->setData('ptype_attribute_id', $this->getProductattribute()->getId())
                ->setData('store_id', 0);	
			$this->setId($option->getId());	
			$this->getValueInstance()->deleteValue($this->getId());
            $this->deletePrices($this->getId());
            $this->deleteTitles($this->getId());
            $this->delete();
			}catch (Exception $e) {
				Mage::log($e->getMessage(),null,"delete.log",true);
			}
		}
	}
    /**
     * After save
     *
     * @return Mage_Core_Model_Abstract
     */
    protected function _afterSave()
    {
        $this->getValueInstance()->unsetValues();
        if (is_array($this->getData('values'))) {
            foreach ($this->getData('values') as $value) {
                $this->getValueInstance()->addValue($value);
            }

            $this->getValueInstance()->setOption($this)
                ->saveValues();
        } elseif ($this->getGroupByType($this->getType()) == self::OPTION_GROUP_SELECT) {
            Mage::throwException(Mage::helper('catalog')->__('Select type options required values rows.'));
        }

        return parent::_afterSave();
    }

    /**
     * Return price. If $flag is true and price is percent
     *  return converted percent to price
     *
     * @param bool $flag
     * @return decimal
     */
    public function getPrice($flag = false)
    {
        if ($flag && $this->getPriceType() == 'percent') {
            $basePrice = $this->getProductattribute()->getFinalPrice();
            $price = $basePrice * ($this->_getData('price')/100);
            return $price;
        }
        return $this->_getData('price');
    }

    /**
     * Delete prices of option
     *
     * @param int $option_id
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function deletePrices($option_id)
    {
        $this->getResource()->deletePrices($option_id);
        return $this;
    }

    /**
     * Delete titles of option
     *
     * @param int $option_id
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function deleteTitles($option_id)
    {
        $this->getResource()->deleteTitles($option_id);
        return $this;
    }

    /**
     * get Product Option Collection
     *
     * @param LWM_CustomizeProduct_Model_Productattribute $productattribute
     * @return LWM_CustomizeProduct_Model_Mysql4_Productattribute_Option_Collection
     */
    public function getProductattributeOptionCollection(LWM_CustomizeProduct_Model_Productattribute $productattribute)
    {
        $collection = $this->getCollection()
            ->addFieldToFilter('ptype_attribute_id', $productattribute->getId())
            ->addTitleToResult($productattribute->getStoreId())
            ->addPriceToResult($productattribute->getStoreId())
            ->setOrder('sort_order', 'asc')
            ->setOrder('title', 'asc');

        if ($this->getAddRequiredFilter()) {
            $collection->addRequiredFilter($this->getAddRequiredFilterValue());
        }

        $collection->addValuesToResult($productattribute->getStoreId());
        return $collection;
    }

    /**
     * Get collection of values for current option
     *
     * @return Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Option_Value_Collection
     */
    public function getValuesCollection()
    {
        $collection = $this->getValueInstance()
            ->getValuesCollection($this);

        return $collection;
    }

    /**
     * Get collection of values by given option ids
     *
     * @param array $optionIds
     * @param int $store_id
     * @return unknown
     */
    public function getOptionValuesByOptionId($optionIds, $store_id)
    {
        $collection = Mage::getModel('customizeproduct/productattribute_option_value')
            ->getValuesByOption($optionIds, $this->getId(), $store_id);

        return $collection;
    }

    /**
     * Prepare array of options for duplicate
     *
     * @return array
     */
    public function prepareOptionForDuplicate()
    {
        $this->setPtypeAttributeId(null);
        $this->setOptionId(null);
        $newOption = $this->__toArray();
        $_values = $this->getValues();
        if ($_values) {
            $newValuesArray = array();
            foreach ($_values as $_value) {
                $newValuesArray[] = $_value->prepareValueForDuplicate();
            }
            $newOption['values'] = $newValuesArray;
        }

        return $newOption;
    }

    /**
     * Duplicate options for product
     *
     * @param int $oldProductId
     * @param int $newProductId
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function duplicate($oldProductId, $newProductId)
    {
        $this->getResource()->duplicate($this, $oldProductId, $newProductId);

        return $this;
    }

    /**
     * Retrieve option searchable data
     *
     * @param int $productattributeId
     * @param int $storeId
     * @return array
     */
    public function getSearchableData($productattributeId, $storeId)
    {
        return $this->_getResource()->getSearchableData($productattributeId, $storeId);
    }

    /**
     * Clearing object's data
     *
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    protected function _clearData()
    {
        $this->_data = array();
        $this->_values = array();
        return $this;
    }

    /**
     * Clearing cyclic references
     *
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    protected function _clearReferences()
    {
        if (!empty($this->_values)) {
            foreach ($this->_values as $value) {
                $value->unsetOption();
            }
        }
        return $this;
    }

    /**
     * Check whether custom option could have multiple values
     *
     * @return bool
     */
    public function isMultipleType()
    {
        switch ($this->getType()) {
            case self::OPTION_TYPE_MULTIPLE:
            case self::OPTION_TYPE_CHECKBOX:
                return true;
        }
        return false;
    }
}
