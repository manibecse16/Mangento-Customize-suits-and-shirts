<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Product type model for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Model_Cart_Productattribute extends LWM_CustomizeProduct_Model_Cart_Abstract
{
	public function prepareOptions($product_attribute_options,$product,$stitch_image){
		$values='<ul class="poption">';
		$optionIds=array();
		$preparedValue=array();
		/*Validate the customer selected customize product option */
		foreach($product_attribute_options as $key=>$poption){
			$pattribute=Mage::getModel('customizeproduct/productattribute')->load($key);
			$options=$this->_prepareOptions(new Varien_Object($poption),$pattribute,1);
			$optionIds=array_merge($optionIds,array_keys($options));
			foreach($options as $popid=>$option){
				$product->addCustomOption(self::OPTION_PREFIX . $popid, $option['preparedValue']);
				$values.='<li><label>'.$option['label'].'</label><div class="pvalue">'.$option['value'].'</div></li>';
				if($option['attrPattern']!=''){
					$values.='<li><label>'.$option['label'].' Pattern</label><div class="pvalue">'.$option['attrPattern'].'</div></li>';
				}
			}
		}
		$stitch_image=Mage::helper('customizeproduct')->uploadCartImage($stitch_image['stitch_image']);
		$product->addCustomOption('stitch_image',$stitch_image['filelocation']);	
		if($stitch_image){
				$values.='<li><div class="pvalue"><img src="/media/'.$stitch_image['filelocation'].'" /></div></li>';
		}
		/*Save the customer selected customize product option ids */
		if($optionIds){
		  $product->addCustomOption('poption_ids',implode(',',$optionIds));	
		}
	
		$values.="</ul>";
		return $values;
	}
	/**
     * Apply options price
     *
     * @param Mage_Catalog_Model_Product $product
     * @param int $qty
     * @param float $finalPrice
     * @return float
     */
    public function _applyOptionsPrice($product, $qty, $finalPrice)
    {
        if ($optionIds = $product->getCustomOption('poption_ids')) {
            $basePrice = $finalPrice;
            foreach (explode(',', $optionIds->getValue()) as $optionId) {
                if ($option = $this->getOptionById($optionId)) {
					$optiondetails=Mage::getModel('customizeproduct/productattribute')->load($option->getPtypeAttributeId())->getOptionById($optionId);
					
                    $confItemOption = $product->getCustomOption(self::OPTION_PREFIX.$option->getId());
                    
                    $group = $optiondetails->groupFactory($optiondetails->getType())
                        ->setOption($optiondetails)
                        ->setConfigurationItemOption($confItemOption);
                    $finalPrice += $group->getOptionPrice($confItemOption->getValue(), $basePrice);
                }
            }
        }

        return $finalPrice;
    }
	protected function getOptionById($optionId)
    {
		$collection=Mage::getSingleton('customizeproduct/productattribute_option')->getCollection();
		$collection->addFieldToFilter('option_id', $optionId)->getFirstItem();

		foreach($collection as $data){
		  return  $data;
	    }
	   return false;
	} 
}