<?php
class LWM_CustomizeProduct_Model_Mysql4_Productattribute extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("customizeproduct/productattribute", "ptype_attribute_id");
    }
}