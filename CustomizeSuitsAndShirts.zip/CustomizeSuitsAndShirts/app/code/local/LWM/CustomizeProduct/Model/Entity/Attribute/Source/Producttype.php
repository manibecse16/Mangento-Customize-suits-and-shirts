<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Display the all the product type list in product edit/add section
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Model_Entity_Attribute_Source_Producttype extends Mage_Eav_Model_Entity_Attribute_Source_Abstract
{
	/**
     * Return all available product type for the  attributes, i.e. a list of all
     * available payment options All Payment Methods
     *
     * @return array
     */
    public function getAllOptions()
    {
        if (is_null($this->_options)) {
			$this->_options[] = array("value"=>"0","label"=>"None");
			$collection = Mage::getModel("customizeproduct/producttype")->getCollection();	
			foreach ($collection as $value) {
					$this->_options[] = array(
						'value' =>$value->getId(),
						'label' =>$value->getPtypeName(),
					);
				}
			}
		 return $this->_options;
	}
    /**
     * Get the label for an option value. If the value is a comma
     * separated string or an array, return an array of matching
     * option labels.
     *
     * @param string|integer $value
     * @return string|array
     */
    public function getOptionText($value)
    {
        $options = $this->getAllOptions();

        if (is_scalar($value) && strpos($value, ',')) {
            $value = explode(',', $value);
        }
        if (is_array($value)) {
            $values = array();
            foreach ($options as $item) {
                if (in_array($item['value'], $value)) {
                    $values[] = $item['label'];
                }
            } 
            return $values;
        } else {
            foreach ($options as $item) {
                if ($item['value'] == $value) {
                    return $item['label'];
                }
            }
        }
        return false;
    }
}