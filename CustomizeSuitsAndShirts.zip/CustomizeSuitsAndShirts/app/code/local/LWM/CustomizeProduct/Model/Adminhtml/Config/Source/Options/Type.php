<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managig the options type
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Model_Adminhtml_Config_Source_Options_Type
{
    const CUSTOMIZE_PRODUCT_OPTIONS_GROUPS_PATH ='global/customizeproduct/options/custom/groups';

    public function toOptionArray()
    {
        $groups = array(
            array('value' => '', 'label' => Mage::helper('adminhtml')->__('-- Please select --'))
        );

        $helper = Mage::helper('catalog');

        foreach (Mage::getConfig()->getNode(self::CUSTOMIZE_PRODUCT_OPTIONS_GROUPS_PATH)->children() as $group) {
            $types = array();
            $typesPath = self::CUSTOMIZE_PRODUCT_OPTIONS_GROUPS_PATH . '/' . $group->getName() . '/types';
            foreach (Mage::getConfig()->getNode($typesPath)->children() as $type) {
                $labelPath = self::CUSTOMIZE_PRODUCT_OPTIONS_GROUPS_PATH . '/' . $group->getName() . '/types/' . $type->getName()
                    . '/label';
                $types[] = array(
                    'label' => $helper->__((string) Mage::getConfig()->getNode($labelPath)),
                    'value' => $type->getName()
                );
            }

            $labelPath = self::CUSTOMIZE_PRODUCT_OPTIONS_GROUPS_PATH . '/' . $group->getName() . '/label';

            $groups[] = array(
                'label' => $helper->__((string) Mage::getConfig()->getNode($labelPath)),
                'value' => $types
            );
        }

        return $groups;
    }
}