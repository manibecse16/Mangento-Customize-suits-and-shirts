<?php

class LWM_CustomizeProduct_Model_Observer
{
	const CUSTOMIZE_PRODUCT_DESIGN = "customize_product_design";
	public function addCustomOptions(Varien_Event_Observer $observer) {
		$product = $observer->getProduct();
		$product_id = $product->getId();
		$product_attribute_options=Mage::app()->getRequest()->getParam('productattributeoptions');
		if($product_attribute_options) {
			$action = Mage::app()->getFrontController()->getAction();
			if($action->getFullActionName() == 'checkout_cart_add'||$action->getFullActionName() == 'checkout_cart_updateItemOptions'|| $action->getFullActionName() == 'arajaxcart_index_add') {
				$ptype=Mage::helper('customizeproduct')->getProducttypedetails($product->getCustomizeProductDesign());
				if($ptype){
				$stitch_image=Mage::app()->getRequest()->getParam('_processing_params');	
				$cart_model=Mage::getModel('customizeproduct/cart_productattribute');
				$label = $ptype->getPtypeName().' Options'; // Label
				$value=$cart_model->prepareOptions($product_attribute_options,$product,$stitch_image);
				$options = array($label => $value);
					if ($options) {
						$additionalOptions = array();
						if ($additionalOption = $product->getCustomOption('additional_options')) {
							$additionalOptions = (array) unserialize($additionalOption->getValue());
						}
						foreach ($options as $key => $value) {
							$additionalOptions[] = array(
								'label' => $key,
								'value' => $value,
							);
						}
						$observer->getProduct()->addCustomOption('additional_options', serialize($additionalOptions));
					}
				}
			}
		}
	}
	public function updateCustomOptions(Varien_Event_Observer $observer){
		$quote_item=$observer->getQuoteItem();
		$product=$observer->getProduct();
		Mage::log($product->getCustomizeProductDesign(),null,"test.log",true);
		Mage::log($quote_item->getOptionByCode('additional_options'),null,"test1.log",true);
	}
	public function convertQuoteItemToOrderItem(Varien_Event_Observer $observer) {
		$quoteItem = $observer->getItem();
	Mage::log("testing",null,"test.log",true);
		if ($additionalOptions = $quoteItem->getOptionByCode('additional_options')) {
				Mage::log($quoteItem->getOptionByCode('stitch_image'),null,"test.log",true);
			$stitch_image=Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).$quoteItem->getOptionByCode('stitch_image');
			Mage::log($stitch_image,null,"test.log",true);
			$stitch_image_new=Mage::helper('customizeproduct')->moveCartImage($stitch_image);
			Mage::log($stitch_image_new,null,"test.log",true);
			$orderItem = $observer->getOrderItem();
			$options = $orderItem->getProductOptions();
			$options['additional_options'] = unserialize($additionalOptions->getValue());		
			$orderItem->setProductOptions($options);
		}
	}
	public function updateProductattributeprice($observer){
		$product=$observer->getProduct();
		$qty=$observer->getQty();
		$finalprice=$product->getData('final_price');
		$custom_price=Mage::getModel('customizeproduct/cart_productattribute')->_applyOptionsPrice($product,$qty,$finalprice);
		$product->setFinalPrice($custom_price);
		//Mage::log($custom_price,null,"options.log",true);
	}
	public function getCustomerMeasurementInfo(Varien_Event_Observer $observer) {
        $block = $observer->getBlock();
        // layout name should be same as used in app/design/adminhtml/default/default/layout/mymodule.xml
        if (($block->getNameInLayout() == 'order_info') && ($child = $block->getChild('customer_measurement'))) {
            $transport = $observer->getTransport();
            if ($transport) {
                $html = $transport->getHtml();
                $html .= $child->toHtml();
                $transport->setHtml($html);
            }
        }
    }
	public function addAttributeHandle(Varien_Event_Observer $observer){
		 $product = Mage::registry('current_product');
		 /**
		 * Return if it is not product page
		 */
		if (!($product instanceof Mage_Catalog_Model_Product)) {
			return;
		}
		$customize_product_design=$product->getData('customize_product_design');
		if($customize_product_design){
			/* @var $update Mage_Core_Model_Layout_Update */
          $update = $observer->getEvent()->getLayout()->getUpdate();
          $update->addHandle('PRODUCT_ATTRIBUTE_CUSTOMIZE_PRODUCT');
		}
		//Mage::log($customize_product_design,null,"debug.log",true);
	}
}