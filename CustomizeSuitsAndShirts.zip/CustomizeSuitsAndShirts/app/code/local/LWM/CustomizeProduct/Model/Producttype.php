<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Product type model for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Model_Producttype extends Mage_Core_Model_Abstract
{
	protected $_colorInstance;

    protected $_coloroptions = array();
	
    protected function _construct(){

       $this->_init("customizeproduct/producttype");

    }
	/**
     * Get all options of Productattribute
     *
     * @return array
     */
    public function getColorImages()
    {
        return $this->_coloroptions;
    }
	/**
     * Get store id of Productattribute
     *
     * @return array
     */
	public function getStoreId(){
		
        return 0;
    }
	
	/**
     * Retrieve option instance
     *
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function getColorImageInstance()
    {
        if (!$this->_colorInstance) {
            $this->_colorInstance = Mage::getSingleton('customizeproduct/producttype_color_image');
        }
        return $this->_colorInstance;
    }
	/**
     * Retrieve options collection of product
     *
     * @return Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Option_Collection
     */
    public function getColorImageCollection()
    {
        $collection = $this->getColorImageInstance()
            ->getColorImageCollection($this);

        return $collection;
    }
/**
     * Saving product type related data and init index
     *
     * @return LWM_CustomizeProduct_Model_Producttype
     */
    protected function _afterSave()
    {
        /**
         * Product Options
         */
       /*  $this->getColorImageInstance()->setProductattribute($this)
            ->saveOptions();
 */
/*  print_r($_FILES);
 exit; */
 /* $color_image_files=$_FILES['ptype_base_front_color_image'];
 
 Mage::log($_FILES,null,"image.log",true);
 foreach($color_image_files as $value){
	 if($value['error']==0){
            		 
	 }
 }
 $color_options=Mage::app()->getRequest()->getParam('color_option');
 foreach($color_options as $color_id){
	 $color_image_files=$_FILES['ptype_base_front_color_image_'.$color_id]; 
	 Mage::log($color_id,null,"image.log",true);
	 Mage::log($color_image_files,null,"image.log",true);
 }
        return parent::_afterSave(); */
    }
}
	 