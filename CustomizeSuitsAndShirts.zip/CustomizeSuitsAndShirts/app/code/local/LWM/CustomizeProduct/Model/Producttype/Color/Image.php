<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Managing the Product type model for customize product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
class LWM_CustomizeProduct_Model_Producttype_Color_Image extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("customizeproduct/producttype_color_image");

    }
	/**
     * get Product Option Collection
     *
     * @param LWM_CustomizeProduct_Model_Producttype $producttype
     * @return LWM_CustomizeProduct_Model_Mysql4_Producttype_Color_Image_Collection
     */
    public function getColorImageCollection(LWM_CustomizeProduct_Model_Producttype $producttype)
    {
        $collection = $this->getCollection()
            ->addFieldToFilter('ptype_id', $producttype->getId());
        return $collection;
    }
	public function SaveColorImage(LWM_CustomizeProduct_Model_Producttype $producttype){
        	 
	}

}
	 