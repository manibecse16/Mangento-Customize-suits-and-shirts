<?php

class LWM_CustomizeProduct_Model_Productattribute extends Mage_Core_Model_Abstract
{
	protected $_optionInstance;

    protected $_options = array();
	
	protected $_canAffectOptions = false;
	/**
     * description
     *
     * @var    mixed
     */
    protected $_productattributeOptions = array();

	
    protected function _construct(){

       $this->_init("customizeproduct/productattribute");

    }
	/**
     * Add option to array of product options
     *
     * @param LWM_CustomizeProduct_Model_Productattribute_Option $option
     * @return LWM_CustomizeProduct_Model_Productattribute
     */
    public function addOption(LWM_CustomizeProduct_Model_Productattribute_Option $option)
    {
        $this->_options[$option->getId()] = $option;
		
        return $this;
    }
	/**
     * Get option from options array of product by given option id
     *
     * @param int $optionId
     * @return LWM_CustomizeProduct_Model_Productattribute_Option | null
     */
    public function getOptionById($optionId)
    {
        if (isset($this->_options[$optionId])) {
            return $this->_options[$optionId];
        }

        return null;
    }

    /**
     * Get all options of Productattribute
     *
     * @return array
     */
    public function getOptions()
    {
        return $this->_options;
    }
	/**
     * Get store id of Productattribute
     *
     * @return array
     */
	public function getStoreId(){
		
        return 0;
    }
	
	/**
     * Retrieve option instance
     *
     * @return LWM_CustomizeProduct_Model_Productattribute_Option
     */
    public function getOptionInstance()
    {
        if (!$this->_optionInstance) {
            $this->_optionInstance = Mage::getSingleton('customizeproduct/productattribute_option');
        }
        return $this->_optionInstance;
    }
	/**
     * Load product options if they exists
     *
     * @return LWM_CustomizeProduct_Model_Productattribute
     */
    protected function _afterLoad()
    {
        parent::_afterLoad();
        /**
         * Load product options
         */
            foreach ($this->getProductattributeOptionsCollection() as $option) {
                $option->setProductattribute($this);
                $this->addOption($option);
            }
        
        return $this;
    }
	public function loadOptions()
    {
          foreach ($this->getProductattributeOptionsCollection() as $option) {
                $option->setProductattribute($this);
                $this->addOption($option);
            }
	 return $this;		
    }
	/**
     * Get preconfigured values from product
     *
     * @return Varien_Object
     */
    public function getPreconfiguredValues()
    {
        $preconfiguredValues = $this->getData('preconfigured_values');
        if (!$preconfiguredValues) {
            $preconfiguredValues = new Varien_Object();
        }

        return $preconfiguredValues;
    }
	/**
     * Retrieve options collection of product
     *
     * @return Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Option_Collection
     */
    public function getProductattributeOptionsCollection()
    {
        $collection = $this->getOptionInstance()
            ->getProductattributeOptionCollection($this);

        return $collection;
    }
	/**
     * Saving product type related data and init index
     *
     * @return LWM_CustomizeProduct_Model_Productattribute
     */
    protected function _afterSave()
    {
        /**
         * Product Options
         */
        $this->getOptionInstance()->setProductattribute($this)
            ->saveOptions();

        return parent::_afterSave();
    }
	/**
     * Delete productattribute type related data and init index
     *
     * @return LWM_CustomizeProduct_Model_Productattribute
     */
    protected function _beforeDelete()
    {
		foreach ($this->getProductattributeOptionsCollection() as $option) {
                $option->setProductattribute($this);
                $this->addOption($option);
            }
	    $this->getOptionInstance()->setOptions($this->getOptions());
	    $this->getOptionInstance()->setProductattribute($this)->deleteOptions();
        return parent::_beforeDelete();
    }
	
   /**
     * Parse buyRequest into options values used by product
     *
     * @param  Varien_Object $buyRequest
     * @return Varien_Object
     */
    public function processBuyRequest(Varien_Object $buyRequest)
    {
        $options = new Varien_Object();

        /* add product custom options data */
        $customOptions = $buyRequest->getProductattributeoptions();
        if (is_array($customOptions)) {
            foreach ($customOptions as $key => $value) {
                if ($value === '') {
                    unset($customOptions[$key]);
                }
            }
            $options->setOptions($customOptions);
        }


        return $options;
    }

}
	 