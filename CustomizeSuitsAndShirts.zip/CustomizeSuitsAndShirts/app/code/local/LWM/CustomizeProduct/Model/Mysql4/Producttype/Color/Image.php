<?php
class LWM_CustomizeProduct_Model_Mysql4_Producttype_Color_Image extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("customizeproduct/producttype_color_image", "id");
    }
}