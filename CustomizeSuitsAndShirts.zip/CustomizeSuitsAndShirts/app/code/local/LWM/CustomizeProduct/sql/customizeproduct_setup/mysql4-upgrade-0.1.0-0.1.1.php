<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * New custom_design attribute creation for catalog_product
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
$installer=$this;
$installer->startSetup();
$setup = new Mage_Eav_Model_Entity_Setup('core_setup');
// Add new attributes
$setup->addAttributeGroup('catalog_product', 'Default', 'Customize Product', 1000);
$setup->addAttribute('catalog_product','customize_product_design', array(
    'label' => 'Select Product type',
    'group' => 'Customize Product',
    'type' => 'int',
    'input' => 'select',
    'source' => 'customizeproduct/entity_attribute_source_producttype',
	'backend' => '',
    'global' => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
    'required' => 0,
    'default' => '-1',
    'user_defined' => 0,
    'filterable_in_search' => 0,
    'is_configurable' => 0,
    'used_in_product_listing' => 1,
));
$installer->endSetup();