<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Creating the new table for options
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT

create table customize_product_type(
            ptype_id int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Product Type ID',
  			ptype_name varchar(255) DEFAULT NULL COMMENT 'Name',
			ptype_base_front_image  varchar(255) DEFAULT NULL COMMENT 'Front Image',
			ptype_base_back_image  varchar(255) DEFAULT NULL COMMENT 'Back Image',
			primary key(ptype_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customize Product Type';	;


create table customize_product_type_attribute(
          ptype_attribute_id int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Product Type ID',
		  ptype_attribute_name varchar(255) DEFAULT NULL COMMENT 'Name',
          ptype_id int(10) UNSIGNED NOT NULL,
          ptype_attribute_view varchar(255) DEFAULT NULL COMMENT 'Attribute View',
		  ptype_attribute_pattern varchar(255) DEFAULT NULL COMMENT 'Attribute Pattern',
		  ptype_attribute_group varchar(255) DEFAULT NULL COMMENT 'Attribute Group',
		  ptype_attribute_front_image varchar(255) DEFAULT NULL COMMENT 'Front image for combine group',
		 `has_options` SMALLINT NOT NULL,
		 `required_options` SMALLINT NOT NULL,
		 `sort_order` INT NOT NULL,
		  primary key(ptype_attribute_id),
		  FOREIGN KEY (ptype_id) REFERENCES customize_product_type(ptype_id)
);	

CREATE TABLE `customize_product_type_option` (
  `option_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Option ID',
  `ptype_attribute_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Customize product attribute id',
  `type` varchar(50) DEFAULT NULL COMMENT 'Type',
  `is_require` smallint(6) NOT NULL DEFAULT '1' COMMENT 'Is Required',
  `sku` varchar(64) DEFAULT NULL COMMENT 'SKU',
  `max_characters` int(10) UNSIGNED DEFAULT NULL COMMENT 'Max Characters',
  `file_extension` varchar(50) DEFAULT NULL COMMENT 'File Extension',
  `image_size_x` smallint(5) UNSIGNED DEFAULT NULL COMMENT 'Image Size X',
  `image_size_y` smallint(5) UNSIGNED DEFAULT NULL COMMENT 'Image Size Y',
  `sort_order` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Sort Order',
   primary key(option_id),
   FOREIGN KEY (ptype_attribute_id) REFERENCES customize_product_type_attribute(ptype_attribute_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customize Product Option Table';	

CREATE TABLE `customize_product_type_option_price` (
  `option_price_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Option Price ID',
  `option_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Option ID',
  `store_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `price` decimal(12,4) NOT NULL DEFAULT '0.0000' COMMENT 'Price',
  `price_type` varchar(7) NOT NULL DEFAULT 'fixed' COMMENT 'Price Type',
   primary key(option_price_id),
   FOREIGN KEY (option_id) REFERENCES customize_product_type_option(option_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customize Product Option Price Table';

CREATE TABLE `customize_product_type_option_title` (
  `option_title_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Option Title ID',
  `option_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Option ID',
  `store_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `title` varchar(255) DEFAULT NULL COMMENT 'Title',
   primary key(option_title_id),
   FOREIGN KEY (option_id) REFERENCES customize_product_type_option(option_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customize Product Option Title Table';

CREATE TABLE `customize_product_type_option_type_value` (
  `option_type_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Option Type ID',
  `option_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Option ID',
  `sku` varchar(64) DEFAULT NULL COMMENT 'SKU',
  `sort_order` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Sort Order',
   primary key(option_type_id),
   FOREIGN KEY (option_id) REFERENCES customize_product_type_option(option_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customize Product Option Type Value Table';

CREATE TABLE `customize_product_type_option_type_image` (
  `option_type_image_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `option_type_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `option_image_small` varchar(255) DEFAULT '',
  `option_image_bg` varchar(255) DEFAULT '',
  `option_image_left_side` varchar(255) DEFAULT '',
  `option_image_right_side` varchar(255) DEFAULT '',
  `option_image_both_side` varchar(255) DEFAULT '',
  `sort_order` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `store_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `source` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1-file,2-color,3-gallery',
   primary key(option_type_image_id),
   FOREIGN KEY (option_type_id) REFERENCES customize_product_type_option_type_value(option_type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customize Product Option Type Image Table';

CREATE TABLE `customize_product_type_option_type_title` (
  `option_type_title_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Option Type Title ID',
  `option_type_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Option Type ID',
  `store_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `title` varchar(255) DEFAULT NULL COMMENT 'Title',
  primary key(option_type_title_id),
  FOREIGN KEY (option_type_id) REFERENCES customize_product_type_option_type_value(option_type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customize Product Option Type Title Table';

CREATE TABLE `customize_product_type_option_type_price` (
  `option_type_price_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Option Type Price ID',
  `option_type_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Option Type ID',
  `store_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `price` decimal(12,4) NOT NULL DEFAULT '0.0000' COMMENT 'Price',
  `price_type` varchar(7) NOT NULL DEFAULT 'fixed' COMMENT 'Price Type',
   primary key(option_type_price_id),
  FOREIGN KEY (option_type_id) REFERENCES customize_product_type_option_type_value(option_type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customize Product Option Type Price Table';

CREATE TABLE `customize_product_measurement_size` ( `id` INT NOT NULL AUTO_INCREMENT , `length_neck` DECIMAL(10,2) NOT NULL , `shoulders` DECIMAL(10,2) NOT NULL , `left_sleeves` DECIMAL(10,2) NOT NULL , `right_sleeves` DECIMAL(10,2) NOT NULL , `chest` DECIMAL(10,2) NOT NULL , `up_waist` DECIMAL(10,2) NOT NULL , `hips` DECIMAL(10,2) NOT NULL , `front_chest` DECIMAL(10,2) NOT NULL , `back_shoulders` DECIMAL(10,2) NOT NULL , `neck` DECIMAL(10,2) NOT NULL , `wrist` DECIMAL(10,2) NOT NULL , `biceps` DECIMAL(10,2) NOT NULL , `customer_id` INT NOT NULL ,`measurement_type` ENUM('Jacket','Shirt') NOT NULL,PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `customize_product_pant_size` ( `id` INT NOT NULL AUTO_INCREMENT , `waist` DECIMAL(10,2) NOT NULL , `hips` DECIMAL(10,2) NOT NULL , `trouser_length` DECIMAL(10,2) NOT NULL , `bottom` DECIMAL(10,2) NOT NULL , `knee` DECIMAL(10,2) NOT NULL , `thigh` DECIMAL(10,2) NOT NULL , `crotch` DECIMAL(10,2) NOT NULL , `customer_id` INT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
CREATE TABLE `customize_product_type_option_color_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_type_image_id` int(11) NOT NULL COMMENT 'Option type image id',
  `option_attribute_color_id` int(11) NOT NULL COMMENT 'Color attrbute option id',
  `option_image_small` varchar(255) NOT NULL,
  `option_image_bg` varchar(255) NOT NULL,
  `option_image_left_side` varchar(255) NOT NULL,
  `option_image_right_side` varchar(255) NOT NULL,
  `option_image_both_side` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `customize_product_attribute_option_image`
  ADD PRIMARY KEY (`id`);
 
CREATE TABLE `custommen`.`customize_product_type_color_image` ( `id` INT NOT NULL AUTO_INCREMENT, `ptype_id` INT NOT NULL , `color_option_id` INT NOT NULL , `ptype_base_front_image` VARCHAR(255) NOT NULL , `ptype_base_back_image` VARCHAR(255) NOT NULL ) ENGINE = InnoDB;

ALTER TABLE `customize_product_type_color_image`
  ADD PRIMARY KEY (`id`);
  
SQLTEXT;

$installer->run($sql);
$installer->endSetup();